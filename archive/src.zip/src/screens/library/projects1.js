// src/screens/library/ProjectsScreen.js
// Projects home — mission control dashboard

import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  TextInput, Modal, FlatList, ActivityIndicator,
  RefreshControl, Alert, KeyboardAvoidingView, Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { useTheme } from '../../../context/ThemeContext';
import { supabase } from '../../api/supabaseClient';

const CATEGORIES = [
  { key: 'all',          label: 'All',          emoji: '🌌' },
  { key: 'active',       label: 'Active',        emoji: '🚀' },
  { key: 'completed',    label: 'Completed',     emoji: '✅' },
  { key: 'idea',         label: 'Ideas',         emoji: '💡' },
  { key: 'showcase',     label: 'Showcase',      emoji: '🏆' },
];

const PROJECT_TYPES = [
  '🔬 Science',  '💻 Coding',   '🎨 Art',      '📝 Writing',
  '💰 Business', '🏗️ DIY',     '📚 Research', '🎯 Personal',
  '✈️ Travel',   '🎵 Music',   '📊 Finance',  '🌱 Other',
];

const COLORS = [
  '#e05858','#c9a84c','#2bb5a0','#8b4fc4',
  '#3ac860','#6b9fe8','#e0a830','#5a9ae0',
];

const EMOJIS = ['🚀','💡','🔬','🎨','💻','📝','🏗️','💰','🎯','🌟','⚡','🔥','🌙','🛸','🌊','🦋'];

// ─── New Project Modal ────────────────────────────────────────────────────────
function NewProjectModal({ visible, userId, onCreated, onClose, c, t, s, r }) {
  const [title,     setTitle]     = useState('');
  const [objective, setObjective] = useState('');
  const [emoji,     setEmoji]     = useState('🚀');
  const [color,     setColor]     = useState(COLORS[0]);
  const [type,      setType]      = useState('');
  const [saving,    setSaving]    = useState(false);

  const reset = () => { setTitle(''); setObjective(''); setEmoji('🚀'); setColor(COLORS[0]); setType(''); };

  const create = async () => {
    if (!title.trim()) return;
    setSaving(true);
    try {
      const { data, error } = await supabase.from('projects').insert({
        user_id:      userId,
        title:        title.trim(),
        objective:    objective.trim() || null,
        emoji,
        color,
        cover_color:  color,
        banner_emoji: emoji,
        category:     type || 'general',
        status:       'active',
        sort_order:   0,
      }).select().single();
      if (error) throw error;

      // Log creation milestone
      await supabase.from('project_milestones').insert({
        user_id: userId, project_id: data.id,
        title: 'Mission launched', type: 'project_created', date: new Date().toISOString().split('T')[0],
      });

      onCreated(data);
      reset();
    } catch (e) { Alert.alert('Error', 'Could not create project'); }
    setSaving(false);
  };

  return (
    <Modal visible={visible} transparent animationType="slide">
      <KeyboardAvoidingView style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={{ backgroundColor: c.bg1, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: s.xl, paddingBottom: 48, maxHeight: '90%' }}>
          <View style={{ width: 36, height: 4, borderRadius: 2, backgroundColor: c.border, alignSelf: 'center', marginBottom: s.xl }} />

          {/* Preview */}
          <View style={{ alignItems: 'center', marginBottom: s.xl }}>
            <View style={{ width: 80, height: 80, borderRadius: 20, backgroundColor: color + '33', borderWidth: 2, borderColor: color, alignItems: 'center', justifyContent: 'center', marginBottom: s.sm }}>
              <Text style={{ fontSize: 40 }}>{emoji}</Text>
            </View>
            <Text style={{ fontSize: t.lg, fontWeight: t.bold, color: c.text1 }}>{title || 'New Mission'}</Text>
          </View>

          <ScrollView showsVerticalScrollIndicator={false}>
            {/* Title */}
            <TextInput
              style={{ borderWidth: 1, borderColor: color, borderRadius: r.md, padding: s.md, fontSize: t.md, color: c.text1, backgroundColor: c.bg0, marginBottom: s.md }}
              value={title} onChangeText={setTitle}
              placeholder="Mission name..." placeholderTextColor={c.text4}
              autoFocus
            />

            {/* Objective */}
            <TextInput
              style={{ borderWidth: 1, borderColor: c.border, borderRadius: r.md, padding: s.md, fontSize: t.sm, color: c.text1, backgroundColor: c.bg0, marginBottom: s.md, minHeight: 60, textAlignVertical: 'top' }}
              value={objective} onChangeText={setObjective}
              placeholder="What is the mission objective? (optional)" placeholderTextColor={c.text4}
              multiline
            />

            {/* Emoji picker */}
            <Text style={{ fontSize: t.xs, color: c.text4, textTransform: 'uppercase', letterSpacing: 1, marginBottom: s.sm }}>Mission Icon</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: s.md }}>
              <View style={{ flexDirection: 'row', gap: s.sm }}>
                {EMOJIS.map(em => (
                  <TouchableOpacity key={em} onPress={() => setEmoji(em)}
                    style={{ width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: emoji === em ? color : 'transparent', backgroundColor: emoji === em ? color + '22' : c.bg0 }}>
                    <Text style={{ fontSize: 22 }}>{em}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>

            {/* Color picker */}
            <Text style={{ fontSize: t.xs, color: c.text4, textTransform: 'uppercase', letterSpacing: 1, marginBottom: s.sm }}>Mission Color</Text>
            <View style={{ flexDirection: 'row', gap: s.sm, marginBottom: s.md }}>
              {COLORS.map(col => (
                <TouchableOpacity key={col} onPress={() => setColor(col)}
                  style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: col, borderWidth: 3, borderColor: color === col ? '#fff' : 'transparent' }} />
              ))}
            </View>

            {/* Type */}
            <Text style={{ fontSize: t.xs, color: c.text4, textTransform: 'uppercase', letterSpacing: 1, marginBottom: s.sm }}>Mission Type</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: s.xl }}>
              <View style={{ flexDirection: 'row', gap: s.sm }}>
                {PROJECT_TYPES.map(pt => (
                  <TouchableOpacity key={pt} onPress={() => setType(pt)}
                    style={{ paddingHorizontal: s.md, paddingVertical: 6, borderRadius: r.full, borderWidth: 1, borderColor: type === pt ? color : c.border, backgroundColor: type === pt ? color + '22' : 'transparent' }}>
                    <Text style={{ fontSize: t.xs, color: type === pt ? color : c.text3 }}>{pt}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>

            <View style={{ flexDirection: 'row', gap: s.sm }}>
              <TouchableOpacity onPress={() => { reset(); onClose(); }}
                style={{ flex: 1, padding: s.md, alignItems: 'center', backgroundColor: c.bg0, borderRadius: r.md, borderWidth: 0.5, borderColor: c.border }}>
                <Text style={{ color: c.text3, fontSize: t.sm }}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={create} disabled={!title.trim() || saving}
                style={{ flex: 2, padding: s.md, alignItems: 'center', backgroundColor: color, borderRadius: r.md, opacity: (!title.trim() || saving) ? 0.5 : 1 }}>
                {saving ? <ActivityIndicator color="#fff" size="small" /> : <Text style={{ color: '#fff', fontWeight: t.bold, fontSize: t.sm }}>🚀 Launch Mission</Text>}
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ─── Project Card ─────────────────────────────────────────────────────────────
function ProjectCard({ project, onPress, onFavorite, c, t, s, r }) {
  const color      = project.color || '#2bb5a0';
  const updatedAgo = getTimeAgo(project.updated_at || project.created_at);

  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.85}
      style={{ backgroundColor: c.bg1, borderRadius: r.xl, marginBottom: s.md, borderWidth: 0.5, borderColor: c.border, overflow: 'hidden' }}>
      {/* Color banner */}
      <View style={{ height: 6, backgroundColor: color }} />
      <View style={{ padding: s.lg }}>
        <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: s.md }}>
          {/* Emoji */}
          <View style={{ width: 52, height: 52, borderRadius: 14, backgroundColor: color + '22', borderWidth: 1, borderColor: color + '55', alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ fontSize: 26 }}>{project.emoji || '🚀'}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: t.md, fontWeight: t.bold, color: c.text1, marginBottom: 3 }} numberOfLines={1}>
              {project.title}
            </Text>
            {project.objective && (
              <Text style={{ fontSize: t.xs, color: c.text3, lineHeight: 16 }} numberOfLines={2}>
                {project.objective}
              </Text>
            )}
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: s.sm, marginTop: s.sm }}>
              {project.category && project.category !== 'general' && (
                <View style={{ backgroundColor: color + '22', borderRadius: r.full, paddingHorizontal: 7, paddingVertical: 2 }}>
                  <Text style={{ fontSize: 9, color: color, fontWeight: t.bold }}>{project.category}</Text>
                </View>
              )}
              <Text style={{ fontSize: 10, color: c.text4 }}>{updatedAgo}</Text>
            </View>
          </View>
          {/* Favorite */}
          <TouchableOpacity onPress={() => onFavorite(project)} style={{ padding: 4 }}>
            <Ionicons name={project.is_favorite ? 'star' : 'star-outline'} size={18} color={project.is_favorite ? c.gold : c.text4} />
          </TouchableOpacity>
        </View>

        {/* Quick actions */}
        <View style={{ flexDirection: 'row', gap: s.sm, marginTop: s.md, borderTopWidth: 0.5, borderTopColor: c.border, paddingTop: s.md }}>
          <TouchableOpacity onPress={onPress}
            style={{ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4, backgroundColor: color, borderRadius: r.md, paddingVertical: 7 }}>
            <Ionicons name="rocket-outline" size={13} color="#fff" />
            <Text style={{ fontSize: 11, color: '#fff', fontWeight: t.bold }}>Continue</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{ paddingHorizontal: s.md, paddingVertical: 7, borderRadius: r.md, backgroundColor: c.bg0, borderWidth: 0.5, borderColor: c.border }}>
            <Ionicons name="share-outline" size={15} color={c.text3} />
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );
}

function getTimeAgo(dateStr) {
  if (!dateStr) return '';
  const diff = Date.now() - new Date(dateStr).getTime();
  const days  = Math.floor(diff / 86400000);
  if (days === 0) return 'Today';
  if (days === 1) return 'Yesterday';
  if (days < 7)  return `${days} days ago`;
  if (days < 30) return `${Math.floor(days / 7)} weeks ago`;
  return `${Math.floor(days / 30)} months ago`;
}

// ─── Main ProjectsScreen ──────────────────────────────────────────────────────
export default function ProjectsScreen() {
  const navigation = useNavigation();
  const { colors: c, typography: t, spacing: s, radius: r, shadows: sh } = useTheme();

  const [projects,   setProjects]   = useState([]);
  const [loading,    setLoading]    = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [userId,     setUserId]     = useState(null);
  const [filter,     setFilter]     = useState('all');
  const [showNew,    setShowNew]    = useState(false);
  const [search,     setSearch]     = useState('');

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (user) { setUserId(user.id); load(user.id); }
      else setLoading(false);
    });
  }, []);

  useFocusEffect(useCallback(() => { if (userId) load(userId); }, [userId]));

  const load = async (uid) => {
    setLoading(true);
    try {
      const { data } = await supabase
        .from('projects').select('*').eq('user_id', uid).order('updated_at', { ascending: false });
      if (data) setProjects(data);
    } catch (e) { console.warn('ProjectsScreen', e); }
    setLoading(false);
  };

  const onRefresh = async () => { setRefreshing(true); if (userId) await load(userId); setRefreshing(false); };

  const toggleFavorite = async (proj) => {
    const newVal = !proj.is_favorite;
    setProjects(prev => prev.map(p => p.id === proj.id ? { ...p, is_favorite: newVal } : p));
    await supabase.from('projects').update({ is_favorite: newVal }).eq('id', proj.id);
  };

  const filtered = projects.filter(p => {
    const matchSearch = !search || p.title?.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'all' ? true
      : filter === 'active'    ? p.status === 'active'
      : filter === 'completed' ? p.status === 'completed'
      : filter === 'idea'      ? p.status === 'idea'
      : filter === 'showcase'  ? p.is_showcase
      : true;
    return matchSearch && matchFilter;
  });

  const recent = projects.find(p => p.status === 'active');
  const favorites = projects.filter(p => p.is_favorite);

  return (
    <View style={{ flex: 1, backgroundColor: c.bg0 }}>
      {/* Header */}
      <View style={{ backgroundColor: c.headerBg, padding: s.lg, borderBottomWidth: 0.5, borderBottomColor: c.border }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: s.md }}>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: t.xxl, fontWeight: t.bold, color: c.text1 }}>🛸 Missions</Text>
            <Text style={{ fontSize: t.xs, color: c.text3, marginTop: 2 }}>
              {projects.length} missions · {projects.filter(p => p.status === 'active').length} active
            </Text>
          </View>
          <TouchableOpacity
            onPress={() => setShowNew(true)}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: c.teal, borderRadius: r.xl, paddingHorizontal: s.lg, paddingVertical: s.sm }}>
            <Ionicons name="add" size={18} color="#fff" />
            <Text style={{ color: '#fff', fontWeight: t.bold, fontSize: t.sm }}>New</Text>
          </TouchableOpacity>
        </View>

        {/* Search */}
        <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: c.bg0, borderRadius: r.md, paddingHorizontal: s.md, borderWidth: 0.5, borderColor: c.border }}>
          <Ionicons name="search" size={15} color={c.text3} />
          <TextInput style={{ flex: 1, padding: s.sm, fontSize: t.sm, color: c.text1 }}
            value={search} onChangeText={setSearch}
            placeholder="Search missions..." placeholderTextColor={c.text4} />
        </View>
      </View>

      {/* Category filter */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: s.lg, paddingVertical: s.sm, gap: s.sm }}>
        {CATEGORIES.map(cat => (
          <TouchableOpacity key={cat.key} onPress={() => setFilter(cat.key)}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: s.md, paddingVertical: 6, borderRadius: r.full, borderWidth: 1, borderColor: filter === cat.key ? c.teal : c.border, backgroundColor: filter === cat.key ? c.tealLight || c.bg1 : 'transparent' }}>
            <Text style={{ fontSize: 12 }}>{cat.emoji}</Text>
            <Text style={{ fontSize: t.xs, fontWeight: filter === cat.key ? t.bold : t.regular, color: filter === cat.key ? c.teal : c.text3 }}>{cat.label}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {loading ? <ActivityIndicator style={{ marginTop: 40 }} color={c.teal} /> : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ padding: s.lg, paddingBottom: 60 }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={c.teal} />}
        >
          {/* Continue working */}
          {recent && filter === 'all' && !search && (
            <View style={{ marginBottom: s.xl }}>
              <Text style={{ fontSize: t.xs, fontWeight: t.bold, color: c.gold, textTransform: 'uppercase', letterSpacing: 1.2, marginBottom: s.sm }}>
                ⚡ Continue Working
              </Text>
              <TouchableOpacity onPress={() => navigation.navigate('ProjectDetail', { project: recent })}
                activeOpacity={0.85}
                style={{ backgroundColor: c.bg1, borderRadius: r.xl, borderWidth: 1, borderColor: recent.color || c.teal, overflow: 'hidden' }}>
                <View style={{ height: 4, backgroundColor: recent.color || c.teal }} />
                <View style={{ padding: s.lg, flexDirection: 'row', alignItems: 'center', gap: s.md }}>
                  <View style={{ width: 60, height: 60, borderRadius: 16, backgroundColor: (recent.color || c.teal) + '22', alignItems: 'center', justifyContent: 'center' }}>
                    <Text style={{ fontSize: 30 }}>{recent.emoji || '🚀'}</Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: t.lg, fontWeight: t.bold, color: c.text1 }}>{recent.title}</Text>
                    {recent.objective && <Text style={{ fontSize: t.xs, color: c.text3, marginTop: 3 }} numberOfLines={2}>{recent.objective}</Text>}
                  </View>
                  <Ionicons name="chevron-forward" size={20} color={recent.color || c.teal} />
                </View>
              </TouchableOpacity>
            </View>
          )}

          {/* Favorites */}
          {favorites.length > 0 && filter === 'all' && !search && (
            <View style={{ marginBottom: s.xl }}>
              <Text style={{ fontSize: t.xs, fontWeight: t.bold, color: c.gold, textTransform: 'uppercase', letterSpacing: 1.2, marginBottom: s.sm }}>⭐ Favorites</Text>
              {favorites.map(proj => (
                <ProjectCard key={proj.id} project={proj}
                  onPress={() => navigation.navigate('ProjectDetail', { project: proj })}
                  onFavorite={toggleFavorite} c={c} t={t} s={s} r={r} />
              ))}
            </View>
          )}

          {/* All filtered projects */}
          {filtered.length === 0 ? (
            <View style={{ alignItems: 'center', paddingTop: 60 }}>
              <Text style={{ fontSize: 52, marginBottom: s.lg }}>🛸</Text>
              <Text style={{ fontSize: t.lg, fontWeight: t.bold, color: c.text1, marginBottom: s.sm }}>
                {search ? 'No missions found' : 'No missions yet'}
              </Text>
              <Text style={{ fontSize: t.sm, color: c.text3, textAlign: 'center' }}>
                {search ? 'Try a different search' : 'Tap New to launch your first mission'}
              </Text>
            </View>
          ) : (
            <>
              {(filter !== 'all' || search) && (
                <Text style={{ fontSize: t.xs, fontWeight: t.bold, color: c.text4, textTransform: 'uppercase', letterSpacing: 1, marginBottom: s.sm }}>
                  {filtered.length} mission{filtered.length !== 1 ? 's' : ''}
                </Text>
              )}
              {filter === 'all' && !search && (
                <Text style={{ fontSize: t.xs, fontWeight: t.bold, color: c.gold, textTransform: 'uppercase', letterSpacing: 1.2, marginBottom: s.sm }}>
                  🚀 All Missions
                </Text>
              )}
              {filtered.map(proj => (
                <ProjectCard key={proj.id} project={proj}
                  onPress={() => navigation.navigate('ProjectDetail', { project: proj })}
                  onFavorite={toggleFavorite} c={c} t={t} s={s} r={r} />
              ))}
            </>
          )}
        </ScrollView>
      )}

      <NewProjectModal
        visible={showNew}
        userId={userId}
        onCreated={(proj) => {
          setProjects(prev => [proj, ...prev]);
          setShowNew(false);
          navigation.navigate('ProjectDetail', { project: proj });
        }}
        onClose={() => setShowNew(false)}
        c={c} t={t} s={s} r={r}
      />
    </View>
  );
}
