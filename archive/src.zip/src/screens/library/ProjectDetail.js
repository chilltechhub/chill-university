// src/screens/projects/ProjectDetailScreen.js
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Image, TextInput, FlatList
} from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';

// Sub-modules available inside the Project Workspace
const TABS = [
  { id: 'overview', name: 'Overview', icon: 'planet-outline' },
  { id: 'tasks', name: 'Tasks', icon: 'checkbox-outline' },
  { id: 'research', name: 'Research Hub', icon: 'library-outline' },
  { id: 'notes', name: 'Notes', icon: 'document-text-outline' },
  { id: 'connections', name: 'Knowledge Graph', icon: 'git-network-outline' },
  { id: 'files', name: 'Assets & Files', icon: 'folder-open-outline' },
  { id: 'journal', name: 'Logbook', icon: 'book-outline' },
  { id: 'reflection', name: 'Reflection', icon: 'sparkles-outline' },
  { id: 'skills', name: 'Skills Unlocked', icon: 'trophy-outline' },
  { id: 'ai', name: 'Flight Control AI', icon: 'hardware-chip-outline' },
  { id: 'timeline', name: 'Timeline', icon: 'time-outline' },
  { id: 'impact', name: 'Real-World Impact', icon: 'earth-outline' },
];

export default function ProjectDetailScreen({ route, navigation }) {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <View style={styles.container}>
      {/* Top Mission Control Bar */}
      <View style={styles.topNav}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#FFF" />
        </TouchableOpacity>
        <Text style={styles.missionCode}>MISSION ID: MARS-ROVER-01</Text>
        <TouchableOpacity style={styles.presentBtn}>
          <Ionicons name="easel-outline" size={18} color="#00F0FF" />
          <Text style={styles.presentText}>Present</Text>
        </TouchableOpacity>
      </View>

      {/* Workspace Navigation Bar */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabBar}>
        {TABS.map((tab) => (
          <TouchableOpacity
            key={tab.id}
            style={[styles.tabItem, activeTab === tab.id && styles.activeTabItem]}
            onPress={() => setActiveTab(tab.id)}
          >
            <Ionicons name={tab.icon} size={16} color={activeTab === tab.id ? '#00F0FF' : '#626D82'} />
            <Text style={[styles.tabLabel, activeTab === tab.id && styles.activeTabLabel]}>
              {tab.name}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Main Workspace Frame */}
      <ScrollView contentContainerStyle={styles.contentBody}>
        {activeTab === 'overview' && <OverviewModule />}
        {activeTab === 'tasks' && <TasksModule />}
        {activeTab === 'research' && <ResearchHubModule />}
        {activeTab === 'notes' && <NotesModule />}
        {activeTab === 'connections' && <ConnectionsGraphModule />}
        {activeTab === 'files' && <FilesModule />}
        {activeTab === 'journal' && <JournalModule />}
        {activeTab === 'reflection' && <ReflectionModule />}
        {activeTab === 'skills' && <SkillsModule />}
        {activeTab === 'ai' && <AIMentorModule />}
        {activeTab === 'timeline' && <TimelineModule />}
        {activeTab === 'impact' && <ImpactModule />}
      </ScrollView>
    </View>
  );
}

/* ====================================================================
   MODULE SUB-COMPONENTS
   ==================================================================== */

// 1. OVERVIEW MODULE
function OverviewModule() {
  return (
    <View style={styles.moduleContainer}>
      <View style={styles.bannerContainer}>
        <Image 
          source={{ uri: 'https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?q=80&w=1000' }} 
          style={styles.bannerImage} 
        />
        <View style={styles.bannerBadge}>
          <Text style={styles.badgeText}>DIFFICULTY: HARDCORE 🚀</Text>
        </View>
      </View>
      <Text style={styles.moduleTitle}>Mars Rover Kinematics & Autonomous Nav</Text>
      <Text style={styles.metaText}>Initiated: Aug 12, 2026 • Category: Robotics</Text>
      
      <View style={styles.glassPanel}>
        <Text style={styles.panelHeader}>🎯 MISSION OBJECTIVE</Text>
        <Text style={styles.panelBody}>
          Design and simulate a 6-wheeled rocker-bogie suspension rover capable of navigating simulated Martian terrain using Python kinematic algorithms and ultrasonic proximity feedback.
        </Text>
      </View>
    </View>
  );
}

// 2. TASKS MODULE
function TasksModule() {
  const [tasks, setTasks] = useState([
    { id: '1', title: 'Calculate gear ratio for drive motors', done: true, priority: 'HIGH' },
    { id: '2', title: 'Write ultrasonic sensor distance algorithm', done: false, priority: 'URGENT' },
    { id: '3', title: '3D print chassis mounting brackets', done: false, priority: 'MED' },
  ]);

  return (
    <View style={styles.moduleContainer}>
      <Text style={styles.moduleTitle}>📋 Mission Directives & Tasks</Text>
      {tasks.map(t => (
        <View key={t.id} style={styles.taskCard}>
          <TouchableOpacity onPress={() => {
            setTasks(tasks.map(item => item.id === t.id ? {...item, done: !item.done} : item))
          }}>
            <Ionicons name={t.done ? "checkbox" : "square-outline"} size={22} color={t.done ? "#00E676" : "#00F0FF"} />
          </TouchableOpacity>
          <Text style={[styles.taskTitle, t.done && styles.taskDone]}>{t.title}</Text>
          <View style={styles.priorityBadge}>
            <Text style={styles.priorityText}>{t.priority}</Text>
          </View>
        </View>
      ))}
    </View>
  );
}

// 3. RESEARCH HUB MODULE
function ResearchHubModule() {
  return (
    <View style={styles.moduleContainer}>
      <Text style={styles.moduleTitle}>📚 Transmission & Research Intelligence</Text>
      <TouchableOpacity style={styles.importBtn}>
        <Ionicons name="cloud-upload-outline" size={18} color="#FFF" />
        <Text style={styles.importBtnText}>Import Resource / URL / PDF</Text>
      </TouchableOpacity>
      
      <View style={styles.researchGrid}>
        <View style={styles.researchCard}>
          <Ionicons name="logo-youtube" size={24} color="#FF0000" />
          <Text style={styles.researchTitle}>Rocker-Bogie Physics Explained</Text>
          <Text style={styles.researchType}>Video Link</Text>
        </View>
        <View style={styles.researchCard}>
          <Ionicons name="document-text" size={24} color="#00F0FF" />
          <Text style={styles.researchTitle}>NASA Kinematics Paper (2024)</Text>
          <Text style={styles.researchType}>PDF Document</Text>
        </View>
      </View>
    </View>
  );
}

// 4. NOTES MODULE (Rich Text Snippets)
function NotesModule() {
  return (
    <View style={styles.moduleContainer}>
      <Text style={styles.moduleTitle}>📝 Lab Notes & Code Snippets</Text>
      <View style={styles.glassPanel}>
        <Text style={styles.panelHeader}>⚡ Motor Speed Calculation (Python)</Text>
        <View style={styles.codeBlock}>
          <Text style={styles.codeText}>{"def calc_rpm(velocity, radius):\n    return (velocity / (2 * 3.14159 * radius)) * 60"}</Text>
        </View>
      </View>
    </View>
  );
}

// 5. CONNECTIONS / KNOWLEDGE GRAPH MODULE
function ConnectionsGraphModule() {
  return (
    <View style={styles.moduleContainer}>
      <Text style={styles.moduleTitle}>🕸️ Knowledge Graph Connections</Text>
      <Text style={styles.metaText}>Visualizing links to other concepts and projects</Text>
      <View style={styles.graphPlaceholder}>
        <MaterialCommunityIcons name="graphql" size={60} color="#00F0FF" />
        <Text style={styles.graphText}>Linked to: [Physics 101], [CAD Library], [Python Systems]</Text>
      </View>
    </View>
  );
}

// 6. FILES MODULE
function FilesModule() {
  return (
    <View style={styles.moduleContainer}>
      <Text style={styles.moduleTitle}>📂 Project Assets & File Storage</Text>
      <View style={styles.fileRow}>
        <Ionicons name="cube-outline" size={24} color="#FFB800" />
        <View style={{flex:1, marginLeft:10}}>
          <Text style={styles.fileName}>Chassis_v2.STL</Text>
          <Text style={styles.fileSize}>14.2 MB • 3D CAD File</Text>
        </View>
        <Ionicons name="download-outline" size={20} color="#8E9BB0" />
      </View>
    </View>
  );
}

// 7. JOURNAL LOGBOOK MODULE
function JournalModule() {
  return (
    <View style={styles.moduleContainer}>
      <Text style={styles.moduleTitle}>📖 Captain's Logbook</Text>
      <View style={styles.journalEntry}>
        <Text style={styles.journalDate}>STARDATE: AUG 15, 2026</Text>
        <Text style={styles.journalBody}>Completed chassis assembly. Motor drivers wired successfully. Proceeding to sensor calibration.</Text>
      </View>
    </View>
  );
}

// 8. REFLECTION MODULE
function ReflectionModule() {
  return (
    <View style={styles.moduleContainer}>
      <Text style={styles.moduleTitle}>🪞 Post-Mission Reflection</Text>
      <View style={styles.glassPanel}>
        <Text style={styles.questionText}>What was the biggest obstacle faced during build?</Text>
        <TextInput 
          style={styles.reflectionInput} 
          placeholder="Document challenges overcome..." 
          placeholderTextColor="#626D82"
          multiline
        />
      </View>
    </View>
  );
}

// 9. SKILLS LEARNED MODULE
function SkillsModule() {
  const skills = ['Kinematics', '3D CAD Design', 'Python', 'Circuitry', 'Critical Thinking'];
  return (
    <View style={styles.moduleContainer}>
      <Text style={styles.moduleTitle}>🏆 Telemetry: XP & Skills Mastered</Text>
      <View style={styles.skillChipsContainer}>
        {skills.map((s, idx) => (
          <View key={idx} style={styles.skillChip}>
            <Ionicons name="shield-checkmark" size={14} color="#00E676" />
            <Text style={styles.skillChipText}>{s}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

// 10. AI MENTOR MODULE (Flight Control AI)
function AIMentorModule() {
  return (
    <View style={styles.moduleContainer}>
      <Text style={styles.moduleTitle}>🤖 Flight Control AI Assistance</Text>
      <View style={styles.aiChatBox}>
        <View style={styles.aiMessage}>
          <Text style={styles.aiText}>Greetings Commander! Need help generating a project timeline or reviewing your Python wheel balance algorithm?</Text>
        </View>
      </View>
      <View style={styles.aiInputRow}>
        <TextInput style={styles.aiInput} placeholder="Ask Flight Control..." placeholderTextColor="#626D82" />
        <TouchableOpacity style={styles.aiSendBtn}>
          <Ionicons name="send" size={16} color="#000" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

// 11. TIMELINE MODULE
function TimelineModule() {
  return (
    <View style={styles.moduleContainer}>
      <Text style={styles.moduleTitle}>⏳ Chronological Log History</Text>
      <View style={styles.timelineItem}>
        <View style={styles.timelineDot} />
        <View style={styles.timelineContent}>
          <Text style={styles.timelineDate}>Aug 10, 2026</Text>
          <Text style={styles.timelineEvent}>Project Initialized</Text>
        </View>
      </View>
    </View>
  );
}

// 12. IMPACT MODULE
function ImpactModule() {
  return (
    <View style={styles.moduleContainer}>
      <Text style={styles.moduleTitle}>🌍 Real-World Impact & Scale</Text>
      <View style={styles.glassPanel}>
        <Text style={styles.questionText}>How could this assist your community or turn into a startup enterprise?</Text>
        <TextInput 
          style={styles.reflectionInput} 
          placeholder="Describe future commercial or civic applications..." 
          placeholderTextColor="#626D82"
          multiline
        />
      </View>
    </View>
  );
}

/* ====================================================================
   STYLESHEET
   ==================================================================== */
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B0D17', paddingTop: 45 },
  topNav: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, paddingBottom: 12 },
  missionCode: { color: '#00F0FF', fontSize: 11, fontWeight: 'bold', letterSpacing: 1 },
  presentBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: 'rgba(0,240,255,0.1)', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12, borderWidth: 1, borderColor: '#00F0FF' },
  presentText: { color: '#00F0FF', fontSize: 11, fontWeight: 'bold' },
  tabBar: { borderBottomWidth: 1, borderBottomColor: '#1F263E', maxHeight: 45 },
  tabItem: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 10, borderBottomWidth: 2, borderBottomColor: 'transparent' },
  activeTabItem: { borderBottomColor: '#00F0FF' },
  tabLabel: { color: '#626D82', fontSize: 12, fontWeight: '600' },
  activeTabLabel: { color: '#00F0FF' },
  contentBody: { padding: 20 },
  moduleContainer: { flex: 1 },
  moduleTitle: { color: '#FFF', fontSize: 18, fontWeight: 'bold', marginBottom: 12 },
  metaText: { color: '#8E9BB0', fontSize: 12, marginBottom: 16 },
  bannerContainer: { height: 160, borderRadius: 12, overflow: 'hidden', marginBottom: 16, position: 'relative' },
  bannerImage: { width: '100%', height: '100%' },
  bannerBadge: { position: 'absolute', top: 12, right: 12, backgroundColor: 'rgba(11,13,23,0.85)', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8, borderWidth: 1, borderColor: '#FFB800' },
  badgeText: { color: '#FFB800', fontSize: 10, fontWeight: 'bold' },
  glassPanel: { backgroundColor: '#141829', padding: 16, borderRadius: 12, borderWidth: 1, borderColor: '#1F263E', marginBottom: 16 },
  panelHeader: { color: '#00F0FF', fontSize: 12, fontWeight: 'bold', marginBottom: 8 },
  panelBody: { color: '#A0AABF', fontSize: 14, lineHeight: 20 },
  taskCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#141829', padding: 14, borderRadius: 10, marginBottom: 10, borderWidth: 1, borderColor: '#1F263E', gap: 12 },
  taskTitle: { flex: 1, color: '#FFF', fontSize: 14 },
  taskDone: { textDecorationLine: 'line-through', color: '#626D82' },
  priorityBadge: { backgroundColor: 'rgba(255,64,129,0.2)', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6 },
  priorityText: { color: '#FF4081', fontSize: 9, fontWeight: 'bold' },
  importBtn: { backgroundColor: '#7C4DFF', flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8, padding: 12, borderRadius: 10, marginBottom: 16 },
  importBtnText: { color: '#FFF', fontWeight: 'bold', fontSize: 13 },
  researchGrid: { gap: 10 },
  researchCard: { backgroundColor: '#141829', padding: 14, borderRadius: 10, borderWidth: 1, borderColor: '#1F263E' },
  researchTitle: { color: '#FFF', fontWeight: 'bold', marginTop: 6 },
  researchType: { color: '#626D82', fontSize: 11, marginTop: 2 },
  codeBlock: { backgroundColor: '#06080F', padding: 12, borderRadius: 8, marginTop: 8 },
  codeText: { color: '#00E676', fontFamily: 'monospace', fontSize: 12 },
  graphPlaceholder: { height: 180, backgroundColor: '#141829', borderRadius: 12, borderWidth: 1, borderColor: '#1F263E', justifyContent: 'center', alignItems: 'center', padding: 20 },
  graphText: { color: '#8E9BB0', marginTop: 12, textAlign: 'center', fontSize: 12 },
  fileRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#141829', padding: 12, borderRadius: 10, borderWidth: 1, borderColor: '#1F263E' },
  fileName: { color: '#FFF', fontWeight: '600', fontSize: 13 },
  fileSize: { color: '#626D82', fontSize: 11 },
  journalEntry: { backgroundColor: '#141829', padding: 14, borderRadius: 10, borderLeftWidth: 3, borderLeftColor: '#00F0FF' },
  journalDate: { color: '#00F0FF', fontSize: 10, fontWeight: 'bold', marginBottom: 4 },
  journalBody: { color: '#A0AABF', fontSize: 13 },
  questionText: { color: '#FFF', fontWeight: '600', marginBottom: 10 },
  reflectionInput: { backgroundColor: '#06080F', color: '#FFF', borderRadius: 8, padding: 12, height: 80, textAlignVertical: 'top' },
  skillChipsContainer: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  skillChip: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(0,230,118,0.1)', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, borderWidth: 1, borderColor: '#00E676' },
  skillChipText: { color: '#00E676', fontSize: 12, fontWeight: '600' },
  aiChatBox: { backgroundColor: '#141829', padding: 12, borderRadius: 10, minHeight: 100, marginBottom: 12 },
  aiMessage: { backgroundColor: 'rgba(124,77,255,0.15)', padding: 10, borderRadius: 8, borderWidth: 1, borderColor: '#7C4DFF' },
  aiText: { color: '#E0D7FF', fontSize: 13 },
  aiInputRow: { flexDirection: 'row', gap: 8 },
  aiInput: { flex: 1, backgroundColor: '#141829', borderRadius: 10, paddingHorizontal: 14, color: '#FFF', borderWidth: 1, borderColor: '#1F263E' },
  aiSendBtn: { backgroundColor: '#00F0FF', width: 44, height: 44, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  timelineItem: { flexDirection: 'row', gap: 12, alignItems: 'center' },
  timelineDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: '#00F0FF' },
  timelineContent: { backgroundColor: '#141829', padding: 10, borderRadius: 8, flex: 1 },
  timelineDate: { color: '#626D82', fontSize: 10 },
  timelineEvent: { color: '#FFF', fontWeight: 'bold', fontSize: 12 }
});