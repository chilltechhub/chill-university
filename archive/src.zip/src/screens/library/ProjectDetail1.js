// src/screens/library/ProjectDetailScreen.js
// Full project workspace — mission control

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  TextInput, Modal, FlatList, ActivityIndicator,
  Alert, KeyboardAvoidingView, Platform, Animated,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useTheme } from '../../../context/ThemeContext';
import { supabase } from '../../api/supabaseClient';

// ─── Section tabs ─────────────────────────────────────────────────────────────
const SECTIONS = [
  { key: 'overview',    label: 'Overview',   icon: 'planet-outline' },
  { key: 'tasks',       label: 'Tasks',      icon: 'checkmark-circle-outline' },
  { key: 'journal',     label: 'Journal',    icon: 'journal-outline' },
  { key: 'research',    label: 'Research',   icon: 'search-outline' },
  { key: 'timeline',    label: 'Timeline',   icon: 'time-outline' },
  { key: 'reflection',  label: 'Reflect',    icon: 'sparkles-outline' },
  { key: 'impact',      label: 'Impact',     icon: 'globe-outline' },
  { key: 'ai',          label: 'AI Mentor',  icon: 'hardware-chip-outline' },
];

const REFLECTION_PROMPTS = [
  'What did you learn from this project?',
  'What challenges did you face?',
  'What would you do differently?',
  'What surprised you most?',
  'What are your next ideas?',
  'What skills did you build?',
  'What would version 2 look like?',
];

const IMPACT_PROMPTS = [
  'What problem does this project solve?',
  'Who benefits from this?',
  'How could this be improved?',
  'Could this become a business?',
  'Could this help your community?',
  'What would version 2 look like?',
];

const SKILLS = ['Research','Communication','Creativity','Critical Thinking','Leadership','Programming','Engineering','Writing','Design','Collaboration','Problem Solving','Planning'];

// ─── Tasks section ────────────────────────────────────────────────────────────
function TasksSection({ projectId, userId, projectColor, c, t, s, r }) {
  const [tasks,      setTasks]      = useState([]);
  const [loading,    setLoading]    = useState(true);
  const [input,      setInput]      = useState('');
  const [showInput,  setShowInput]  = useState(false);

  useEffect(() => { load(); }, []);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('project_tasks')
      .select('*').eq('project_id', projectId).order('sort_order');
    if (data) setTasks(data);
    setLoading(false);
  };

  const addTask = async () => {
    if (!input.trim()) return;
    const { data } = await supabase.from('project_tasks').insert({
      user_id: userId, project_id: projectId,
      title: input.trim(), sort_order: tasks.length,
    }).select().single();
    if (data) setTasks(prev => [...prev, data]);
    setInput(''); setShowInput(false);
  };

  const toggleTask = async (task) => {
    const completed = !task.completed;
    setTasks(prev => prev.map(t => t.id === task.id ? { ...t, completed } : t));
    await supabase.from('project_tasks').update({ completed, completed_at: completed ? new Date().toISOString() : null }).eq('id', task.id);
    if (completed) {
      await supabase.from('project_milestones').insert({
        user_id: userId, project_id: projectId,
        title: `✅ ${task.title}`, type: 'task_complete', date: new Date().toISOString().split('T')[0],
      });
    }
  };

  const deleteTask = async (id) => {
    setTasks(prev => prev.filter(t => t.id !== id));
    await supabase.from('project_tasks').delete().eq('id', id);
  };

  const done  = tasks.filter(t => t.completed).length;
  const total = tasks.length;
  const pct   = total > 0 ? (done / total) * 100 : 0;

  if (loading) return <ActivityIndicator color={projectColor} style={{ marginTop: 20 }} />;

  return (
    <View>
      {/* Progress */}
      {total > 0 && (
        <View style={{ marginBottom: s.lg }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 5 }}>
            <Text style={{ fontSize: t.xs, color: c.text3 }}>Mission Progress</Text>
            <Text style={{ fontSize: t.xs, fontWeight: t.bold, color: projectColor }}>{done}/{total} complete</Text>
          </View>
          <View style={{ height: 6, backgroundColor: c.bg2, borderRadius: 3, overflow: 'hidden' }}>
            <View style={{ height: 6, borderRadius: 3, backgroundColor: projectColor, width: `${pct}%` }} />
          </View>
        </View>
      )}

      {/* Add task */}
      {showInput ? (
        <View style={{ flexDirection: 'row', gap: s.sm, marginBottom: s.md }}>
          <TextInput
            style={{ flex: 1, backgroundColor: c.bg0, borderRadius: r.md, padding: s.md, fontSize: t.sm, color: c.text1, borderWidth: 1, borderColor: projectColor }}
            value={input} onChangeText={setInput}
            placeholder="New task..." placeholderTextColor={c.text4}
            autoFocus onSubmitEditing={addTask}
          />
          <TouchableOpacity style={{ backgroundColor: projectColor, borderRadius: r.md, padding: s.md, justifyContent: 'center' }} onPress={addTask}>
            <Ionicons name="checkmark" size={18} color="#fff" />
          </TouchableOpacity>
        </View>
      ) : (
        <TouchableOpacity onPress={() => setShowInput(true)}
          style={{ flexDirection: 'row', alignItems: 'center', gap: s.sm, backgroundColor: c.bg0, borderRadius: r.md, padding: s.md, marginBottom: s.md, borderWidth: 0.5, borderColor: c.border, borderStyle: 'dashed' }}>
          <Ionicons name="add-circle-outline" size={18} color={c.text4} />
          <Text style={{ fontSize: t.sm, color: c.text4 }}>Add task</Text>
        </TouchableOpacity>
      )}

      {/* Task list */}
      {tasks.map(task => (
        <View key={task.id} style={{ flexDirection: 'row', alignItems: 'center', gap: s.sm, backgroundColor: c.bg1, borderRadius: r.md, padding: s.md, marginBottom: s.sm, borderWidth: 0.5, borderColor: c.border }}>
          <TouchableOpacity onPress={() => toggleTask(task)}>
            <View style={{ width: 22, height: 22, borderRadius: 11, borderWidth: 1.5, borderColor: task.completed ? projectColor : c.border, backgroundColor: task.completed ? projectColor : 'transparent', alignItems: 'center', justifyContent: 'center' }}>
              {task.completed && <Ionicons name="checkmark" size={13} color="#fff" />}
            </View>
          </TouchableOpacity>
          <Text style={{ flex: 1, fontSize: t.sm, color: task.completed ? c.text4 : c.text1, textDecorationLine: task.completed ? 'line-through' : 'none' }}>
            {task.title}
          </Text>
          <TouchableOpacity onPress={() => deleteTask(task.id)} style={{ padding: 4 }}>
            <Ionicons name="close" size={15} color={c.text4} />
          </TouchableOpacity>
        </View>
      ))}

      {tasks.length === 0 && (
        <View style={{ alignItems: 'center', paddingVertical: s.xl }}>
          <Text style={{ fontSize: 36, marginBottom: s.sm }}>📋</Text>
          <Text style={{ fontSize: t.sm, color: c.text3 }}>No tasks yet — add one above</Text>
        </View>
      )}
    </View>
  );
}

// ─── Journal section ──────────────────────────────────────────────────────────
function JournalSection({ projectId, userId, projectColor, c, t, s, r }) {
  const [entries,   setEntries]   = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [showAdd,   setShowAdd]   = useState(false);
  const [title,     setTitle]     = useState('');
  const [body,      setBody]      = useState('');
  const [mood,      setMood]      = useState('');
  const [saving,    setSaving]    = useState(false);

  const MOODS = ['🔥','💡','😊','😤','😴','🎉','🤔','💪'];

  useEffect(() => { load(); }, []);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('project_journal')
      .select('*').eq('project_id', projectId).order('created_at', { ascending: false });
    if (data) setEntries(data);
    setLoading(false);
  };

  const addEntry = async () => {
    if (!body.trim()) return;
    setSaving(true);
    const { data } = await supabase.from('project_journal').insert({
      user_id: userId, project_id: projectId,
      title: title.trim() || null, body: body.trim(), mood: mood || null,
    }).select().single();
    if (data) { setEntries(prev => [data, ...prev]); setTitle(''); setBody(''); setMood(''); setShowAdd(false); }
    setSaving(false);
  };

  if (loading) return <ActivityIndicator color={projectColor} style={{ marginTop: 20 }} />;

  return (
    <View>
      <TouchableOpacity onPress={() => setShowAdd(!showAdd)}
        style={{ flexDirection: 'row', alignItems: 'center', gap: s.sm, backgroundColor: projectColor, borderRadius: r.md, padding: s.md, marginBottom: s.md }}>
        <Ionicons name="add" size={18} color="#fff" />
        <Text style={{ color: '#fff', fontWeight: t.bold, fontSize: t.sm }}>New Journal Entry</Text>
      </TouchableOpacity>

      {showAdd && (
        <View style={{ backgroundColor: c.bg1, borderRadius: r.lg, padding: s.lg, marginBottom: s.lg, borderWidth: 0.5, borderColor: projectColor }}>
          {/* Mood picker */}
          <View style={{ flexDirection: 'row', gap: s.sm, marginBottom: s.md }}>
            {MOODS.map(m => (
              <TouchableOpacity key={m} onPress={() => setMood(m === mood ? '' : m)}
                style={{ padding: 6, borderRadius: 8, backgroundColor: mood === m ? projectColor + '33' : 'transparent', borderWidth: mood === m ? 1 : 0, borderColor: projectColor }}>
                <Text style={{ fontSize: 20 }}>{m}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <TextInput style={{ borderWidth: 1, borderColor: c.border, borderRadius: r.md, padding: s.md, fontSize: t.sm, color: c.text1, backgroundColor: c.bg0, marginBottom: s.sm }}
            value={title} onChangeText={setTitle}
            placeholder="Entry title (optional)" placeholderTextColor={c.text4} />
          <TextInput style={{ borderWidth: 1, borderColor: c.border, borderRadius: r.md, padding: s.md, fontSize: t.sm, color: c.text1, backgroundColor: c.bg0, minHeight: 100, textAlignVertical: 'top', marginBottom: s.md }}
            value={body} onChangeText={setBody}
            placeholder="What happened today? What did you learn? What's next?" placeholderTextColor={c.text4}
            multiline autoFocus />
          <View style={{ flexDirection: 'row', gap: s.sm }}>
            <TouchableOpacity onPress={() => setShowAdd(false)} style={{ flex: 1, padding: s.md, alignItems: 'center', backgroundColor: c.bg0, borderRadius: r.md, borderWidth: 0.5, borderColor: c.border }}>
              <Text style={{ color: c.text3 }}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={addEntry} disabled={!body.trim() || saving} style={{ flex: 2, padding: s.md, alignItems: 'center', backgroundColor: projectColor, borderRadius: r.md, opacity: !body.trim() ? 0.5 : 1 }}>
              {saving ? <ActivityIndicator color="#fff" size="small" /> : <Text style={{ color: '#fff', fontWeight: t.bold }}>Save Entry</Text>}
            </TouchableOpacity>
          </View>
        </View>
      )}

      {entries.length === 0 && !showAdd ? (
        <View style={{ alignItems: 'center', paddingVertical: s.xl }}>
          <Text style={{ fontSize: 36, marginBottom: s.sm }}>📓</Text>
          <Text style={{ fontSize: t.sm, color: c.text3 }}>Start journaling your progress</Text>
        </View>
      ) : (
        entries.map(entry => (
          <View key={entry.id} style={{ backgroundColor: c.bg1, borderRadius: r.lg, padding: s.lg, marginBottom: s.md, borderWidth: 0.5, borderColor: c.border, borderLeftWidth: 3, borderLeftColor: projectColor }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: s.sm, marginBottom: s.sm }}>
              {entry.mood && <Text style={{ fontSize: 18 }}>{entry.mood}</Text>}
              <Text style={{ flex: 1, fontSize: t.sm, fontWeight: t.bold, color: c.text1 }}>{entry.title || 'Journal Entry'}</Text>
              <Text style={{ fontSize: t.xs, color: c.text4 }}>{new Date(entry.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</Text>
            </View>
            <Text style={{ fontSize: t.sm, color: c.text2, lineHeight: 20 }}>{entry.body}</Text>
          </View>
        ))
      )}
    </View>
  );
}

// ─── Research section ─────────────────────────────────────────────────────────
function ResearchSection({ projectId, userId, projectColor, c, t, s, r }) {
  const [items,    setItems]    = useState([]);
  const [loading,  setLoading]  = useState(true);
  const [showAdd,  setShowAdd]  = useState(false);
  const [title,    setTitle]    = useState('');
  const [url,      setUrl]      = useState('');
  const [notes,    setNotes]    = useState('');
  const [type,     setType]     = useState('link');
  const [saving,   setSaving]   = useState(false);

  const TYPES = [
    { key: 'link',     label: 'Link',     icon: 'link-outline' },
    { key: 'article',  label: 'Article',  icon: 'newspaper-outline' },
    { key: 'video',    label: 'Video',    icon: 'play-circle-outline' },
    { key: 'book',     label: 'Book',     icon: 'book-outline' },
    { key: 'note',     label: 'Note',     icon: 'document-text-outline' },
    { key: 'image',    label: 'Image',    icon: 'image-outline' },
  ];

  useEffect(() => { load(); }, []);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('project_research')
      .select('*').eq('project_id', projectId).order('created_at', { ascending: false });
    if (data) setItems(data);
    setLoading(false);
  };

  const addItem = async () => {
    if (!title.trim()) return;
    setSaving(true);
    const { data } = await supabase.from('project_research').insert({
      user_id: userId, project_id: projectId,
      title: title.trim(), url: url.trim() || null,
      notes: notes.trim() || null, type,
    }).select().single();
    if (data) { setItems(prev => [data, ...prev]); setTitle(''); setUrl(''); setNotes(''); setShowAdd(false); }
    setSaving(false);
  };

  if (loading) return <ActivityIndicator color={projectColor} style={{ marginTop: 20 }} />;

  return (
    <View>
      <TouchableOpacity onPress={() => setShowAdd(!showAdd)}
        style={{ flexDirection: 'row', alignItems: 'center', gap: s.sm, backgroundColor: projectColor, borderRadius: r.md, padding: s.md, marginBottom: s.md }}>
        <Ionicons name="add" size={18} color="#fff" />
        <Text style={{ color: '#fff', fontWeight: t.bold, fontSize: t.sm }}>Add Resource</Text>
      </TouchableOpacity>

      {showAdd && (
        <View style={{ backgroundColor: c.bg1, borderRadius: r.lg, padding: s.lg, marginBottom: s.md, borderWidth: 0.5, borderColor: projectColor }}>
          {/* Type selector */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: s.md }}>
            <View style={{ flexDirection: 'row', gap: s.sm }}>
              {TYPES.map(tp => (
                <TouchableOpacity key={tp.key} onPress={() => setType(tp.key)}
                  style={{ flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: s.md, paddingVertical: 6, borderRadius: r.full, borderWidth: 1, borderColor: type === tp.key ? projectColor : c.border, backgroundColor: type === tp.key ? projectColor + '22' : 'transparent' }}>
                  <Ionicons name={tp.icon} size={13} color={type === tp.key ? projectColor : c.text3} />
                  <Text style={{ fontSize: 11, color: type === tp.key ? projectColor : c.text3, fontWeight: type === tp.key ? t.bold : t.regular }}>{tp.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
          <TextInput style={{ borderWidth: 1, borderColor: c.border, borderRadius: r.md, padding: s.md, fontSize: t.sm, color: c.text1, backgroundColor: c.bg0, marginBottom: s.sm }}
            value={title} onChangeText={setTitle} placeholder="Title *" placeholderTextColor={c.text4} autoFocus />
          <TextInput style={{ borderWidth: 1, borderColor: c.border, borderRadius: r.md, padding: s.md, fontSize: t.sm, color: c.text1, backgroundColor: c.bg0, marginBottom: s.sm }}
            value={url} onChangeText={setUrl} placeholder="URL (optional)" placeholderTextColor={c.text4} autoCapitalize="none" />
          <TextInput style={{ borderWidth: 1, borderColor: c.border, borderRadius: r.md, padding: s.md, fontSize: t.sm, color: c.text1, backgroundColor: c.bg0, marginBottom: s.md, minHeight: 50, textAlignVertical: 'top' }}
            value={notes} onChangeText={setNotes} placeholder="Notes..." placeholderTextColor={c.text4} multiline />
          <View style={{ flexDirection: 'row', gap: s.sm }}>
            <TouchableOpacity onPress={() => setShowAdd(false)} style={{ flex: 1, padding: s.md, alignItems: 'center', backgroundColor: c.bg0, borderRadius: r.md, borderWidth: 0.5, borderColor: c.border }}>
              <Text style={{ color: c.text3 }}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={addItem} disabled={!title.trim() || saving} style={{ flex: 2, padding: s.md, alignItems: 'center', backgroundColor: projectColor, borderRadius: r.md, opacity: !title.trim() ? 0.5 : 1 }}>
              {saving ? <ActivityIndicator color="#fff" size="small" /> : <Text style={{ color: '#fff', fontWeight: t.bold }}>Save</Text>}
            </TouchableOpacity>
          </View>
        </View>
      )}

      {items.length === 0 && !showAdd ? (
        <View style={{ alignItems: 'center', paddingVertical: s.xl }}>
          <Text style={{ fontSize: 36, marginBottom: s.sm }}>🔬</Text>
          <Text style={{ fontSize: t.sm, color: c.text3 }}>Add articles, links, notes and more</Text>
        </View>
      ) : (
        items.map(item => {
          const tp = TYPES.find(x => x.key === item.type) || TYPES[0];
          return (
            <View key={item.id} style={{ backgroundColor: c.bg1, borderRadius: r.md, padding: s.md, marginBottom: s.sm, borderWidth: 0.5, borderColor: c.border, borderLeftWidth: 3, borderLeftColor: projectColor }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: s.sm }}>
                <Ionicons name={tp.icon} size={16} color={projectColor} />
                <Text style={{ flex: 1, fontSize: t.sm, fontWeight: t.semibold, color: c.text1 }}>{item.title}</Text>
                <Text style={{ fontSize: 10, color: projectColor, textTransform: 'uppercase' }}>{item.type}</Text>
              </View>
              {item.url && <Text style={{ fontSize: t.xs, color: c.teal, marginTop: 4 }} numberOfLines={1}>{item.url}</Text>}
              {item.notes && <Text style={{ fontSize: t.xs, color: c.text3, marginTop: 4 }}>{item.notes}</Text>}
            </View>
          );
        })
      )}
    </View>
  );
}

// ─── Timeline section ─────────────────────────────────────────────────────────
function TimelineSection({ projectId, project, projectColor, c, t, s, r }) {
  const [milestones, setMilestones] = useState([]);
  const [loading,    setLoading]    = useState(true);

  useEffect(() => { load(); }, []);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('project_milestones')
      .select('*').eq('project_id', projectId).order('created_at');
    if (data) setMilestones(data);
    setLoading(false);
  };

  const TYPE_ICONS = {
    project_created: '🚀', task_complete: '✅',
    file_add: '📁', journal: '📓', milestone: '🏆',
  };

  if (loading) return <ActivityIndicator color={projectColor} style={{ marginTop: 20 }} />;

  return (
    <View>
      {milestones.length === 0 ? (
        <View style={{ alignItems: 'center', paddingVertical: s.xl }}>
          <Text style={{ fontSize: 36, marginBottom: s.sm }}>📅</Text>
          <Text style={{ fontSize: t.sm, color: c.text3 }}>Timeline builds as you work</Text>
        </View>
      ) : (
        milestones.map((m, i) => (
          <View key={m.id} style={{ flexDirection: 'row', gap: s.md, marginBottom: s.md }}>
            <View style={{ alignItems: 'center' }}>
              <View style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: projectColor + '22', borderWidth: 1.5, borderColor: projectColor, alignItems: 'center', justifyContent: 'center' }}>
                <Text style={{ fontSize: 16 }}>{TYPE_ICONS[m.type] || '⭐'}</Text>
              </View>
              {i < milestones.length - 1 && (
                <View style={{ width: 2, flex: 1, backgroundColor: projectColor + '33', marginTop: 4 }} />
              )}
            </View>
            <View style={{ flex: 1, paddingTop: 6 }}>
              <Text style={{ fontSize: t.sm, fontWeight: t.semibold, color: c.text1 }}>{m.title}</Text>
              <Text style={{ fontSize: t.xs, color: c.text4, marginTop: 2 }}>
                {new Date(m.created_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
              </Text>
            </View>
          </View>
        ))
      )}
    </View>
  );
}

// ─── Reflection section ───────────────────────────────────────────────────────
function ReflectionSection({ projectId, userId, projectColor, prompts, c, t, s, r }) {
  const [answers,  setAnswers]  = useState({});
  const [saving,   setSaving]   = useState(null);

  const saveAnswer = async (prompt, text) => {
    setSaving(prompt);
    await supabase.from('project_journal').upsert({
      user_id: userId, project_id: projectId,
      title: prompt, body: text, type: 'reflection',
    });
    setSaving(null);
  };

  return (
    <View>
      {prompts.map((prompt, i) => (
        <View key={i} style={{ backgroundColor: c.bg1, borderRadius: r.lg, padding: s.lg, marginBottom: s.md, borderWidth: 0.5, borderColor: c.border }}>
          <Text style={{ fontSize: t.sm, fontWeight: t.semibold, color: projectColor, marginBottom: s.sm }}>
            {i + 1}. {prompt}
          </Text>
          <TextInput
            style={{ fontSize: t.sm, color: c.text1, minHeight: 60, textAlignVertical: 'top', lineHeight: 20 }}
            value={answers[prompt] || ''}
            onChangeText={text => setAnswers(prev => ({ ...prev, [prompt]: text }))}
            onBlur={() => answers[prompt]?.trim() && saveAnswer(prompt, answers[prompt])}
            placeholder="Your thoughts..." placeholderTextColor={c.text4}
            multiline
          />
          {saving === prompt && <ActivityIndicator size="small" color={projectColor} style={{ alignSelf: 'flex-end', marginTop: 4 }} />}
        </View>
      ))}
    </View>
  );
}

// ─── AI Mentor section ────────────────────────────────────────────────────────
function AIMentorSection({ project, projectColor, c, t, s, r }) {
  const [messages, setMessages] = useState([
    { role: 'assistant', text: `🧠 I'm your AI Mentor for **${project.title}**. I can help you brainstorm ideas, break down tasks, suggest resources, review your work, or answer questions. What do you need?` }
  ]);
  const [input,    setInput]    = useState('');
  const [loading,  setLoading]  = useState(false);
  const scrollRef  = useRef(null);

  const send = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const context = `You are an AI mentor helping with a project called "${project.title}". ${project.objective ? `The objective is: ${project.objective}.` : ''} Be encouraging, specific, and practical. Keep responses concise.`;
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-6',
          max_tokens: 1000,
          system: context,
          messages: [
            ...messages.filter(m => m.role !== 'assistant' || messages.indexOf(m) > 0).map(m => ({ role: m.role, content: m.text })),
            { role: 'user', content: userMsg }
          ],
        }),
      });
      const data = await response.json();
      const reply = data.content?.[0]?.text || 'I had trouble processing that. Try again!';
      setMessages(prev => [...prev, { role: 'assistant', text: reply }]);
    } catch {
      setMessages(prev => [...prev, { role: 'assistant', text: 'Connection error. Try again.' }]);
    }
    setLoading(false);
    setTimeout(() => scrollRef.current?.scrollToEnd(), 100);
  };

  const QUICK_PROMPTS = [
    'Break this into tasks', 'Suggest resources', 'Help me brainstorm',
    'Review my progress', 'What should I do next?',
  ];

  return (
    <View style={{ flex: 1 }}>
      {/* Quick prompts */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: s.md }}>
        <View style={{ flexDirection: 'row', gap: s.sm }}>
          {QUICK_PROMPTS.map(qp => (
            <TouchableOpacity key={qp} onPress={() => { setInput(qp); }}
              style={{ paddingHorizontal: s.md, paddingVertical: 6, borderRadius: r.full, backgroundColor: projectColor + '22', borderWidth: 1, borderColor: projectColor }}>
              <Text style={{ fontSize: t.xs, color: projectColor, fontWeight: t.semibold }}>{qp}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      {/* Messages */}
      <ScrollView ref={scrollRef} style={{ flex: 1, maxHeight: 300 }} contentContainerStyle={{ gap: s.sm, paddingBottom: s.sm }}>
        {messages.map((msg, i) => (
          <View key={i} style={{ alignSelf: msg.role === 'user' ? 'flex-end' : 'flex-start', maxWidth: '85%', backgroundColor: msg.role === 'user' ? projectColor : c.bg0, borderRadius: r.lg, padding: s.md, borderWidth: msg.role === 'assistant' ? 0.5 : 0, borderColor: c.border }}>
            <Text style={{ fontSize: t.sm, color: msg.role === 'user' ? '#fff' : c.text1, lineHeight: 20 }}>{msg.text}</Text>
          </View>
        ))}
        {loading && (
          <View style={{ alignSelf: 'flex-start', backgroundColor: c.bg0, borderRadius: r.lg, padding: s.md, borderWidth: 0.5, borderColor: c.border }}>
            <ActivityIndicator size="small" color={projectColor} />
          </View>
        )}
      </ScrollView>

      {/* Input */}
      <View style={{ flexDirection: 'row', gap: s.sm, marginTop: s.md }}>
        <TextInput
          style={{ flex: 1, backgroundColor: c.bg0, borderRadius: r.md, padding: s.md, fontSize: t.sm, color: c.text1, borderWidth: 1, borderColor: c.border }}
          value={input} onChangeText={setInput}
          placeholder="Ask your AI Mentor..." placeholderTextColor={c.text4}
          onSubmitEditing={send} returnKeyType="send"
        />
        <TouchableOpacity onPress={send} disabled={!input.trim() || loading}
          style={{ backgroundColor: projectColor, borderRadius: r.md, padding: s.md, justifyContent: 'center', opacity: (!input.trim() || loading) ? 0.5 : 1 }}>
          <Ionicons name="send" size={18} color="#fff" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

// ─── Main ProjectDetailScreen ─────────────────────────────────────────────────
export default function ProjectDetailScreen() {
  const navigation = useNavigation();
  const route      = useRoute();
  const { colors: c, typography: t, spacing: s, radius: r } = useTheme();

  const [project,  setProject]  = useState(route.params?.project);
  const [section,  setSection]  = useState('overview');
  const [userId,   setUserId]   = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editObj,   setEditObj]   = useState('');

  const color = project?.color || '#2bb5a0';

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => { if (user) setUserId(user.id); });
  }, []);

  const saveEdits = async () => {
    await supabase.from('projects').update({ title: editTitle, objective: editObj }).eq('id', project.id);
    setProject(prev => ({ ...prev, title: editTitle, objective: editObj }));
    setEditMode(false);
  };

  const markComplete = async () => {
    Alert.alert('Complete Mission?', 'Mark this mission as completed?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Complete', onPress: async () => {
        await supabase.from('projects').update({ status: 'completed', completed_at: new Date().toISOString() }).eq('id', project.id);
        await supabase.from('project_milestones').insert({ user_id: userId, project_id: project.id, title: '🏆 Mission Complete!', type: 'milestone', date: new Date().toISOString().split('T')[0] });
        setProject(prev => ({ ...prev, status: 'completed' }));
      }},
    ]);
  };

  if (!project) return null;

  const renderSection = () => {
    switch (section) {
      case 'overview': return (
        <View>
          {/* Objective */}
          <View style={{ backgroundColor: c.bg1, borderRadius: r.lg, padding: s.lg, marginBottom: s.md, borderWidth: 0.5, borderColor: c.border }}>
            <Text style={{ fontSize: t.xs, color: color, textTransform: 'uppercase', letterSpacing: 1, marginBottom: s.sm, fontWeight: t.bold }}>Mission Objective</Text>
            {editMode ? (
              <>
                <TextInput style={{ fontSize: t.sm, color: c.text1, borderWidth: 1, borderColor: color, borderRadius: r.md, padding: s.md, backgroundColor: c.bg0, marginBottom: s.sm }}
                  value={editTitle} onChangeText={setEditTitle} placeholder="Mission name" placeholderTextColor={c.text4} />
                <TextInput style={{ fontSize: t.sm, color: c.text1, borderWidth: 1, borderColor: c.border, borderRadius: r.md, padding: s.md, backgroundColor: c.bg0, minHeight: 80, textAlignVertical: 'top' }}
                  value={editObj} onChangeText={setEditObj} placeholder="Mission objective" placeholderTextColor={c.text4} multiline />
                <TouchableOpacity onPress={saveEdits} style={{ backgroundColor: color, borderRadius: r.md, padding: s.md, alignItems: 'center', marginTop: s.sm }}>
                  <Text style={{ color: '#fff', fontWeight: t.bold }}>Save</Text>
                </TouchableOpacity>
              </>
            ) : (
              <Text style={{ fontSize: t.sm, color: c.text2, lineHeight: 20 }}>
                {project.objective || 'No objective set — tap ✏️ to add one'}
              </Text>
            )}
          </View>

          {/* Meta */}
          <View style={{ backgroundColor: c.bg1, borderRadius: r.lg, padding: s.lg, marginBottom: s.md, borderWidth: 0.5, borderColor: c.border }}>
            <Text style={{ fontSize: t.xs, color: color, textTransform: 'uppercase', letterSpacing: 1, marginBottom: s.md, fontWeight: t.bold }}>Mission Intel</Text>
            {[
              { label: 'Status', value: project.status === 'active' ? '🚀 Active' : project.status === 'completed' ? '✅ Complete' : '💡 Idea' },
              { label: 'Type', value: project.category || 'General' },
              { label: 'Launched', value: new Date(project.created_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }) },
            ].map(row => (
              <View key={row.label} style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6, borderBottomWidth: 0.5, borderBottomColor: c.border }}>
                <Text style={{ fontSize: t.xs, color: c.text3 }}>{row.label}</Text>
                <Text style={{ fontSize: t.xs, fontWeight: t.semibold, color: c.text1 }}>{row.value}</Text>
              </View>
            ))}
          </View>

          {/* Skills */}
          <View style={{ backgroundColor: c.bg1, borderRadius: r.lg, padding: s.lg, borderWidth: 0.5, borderColor: c.border }}>
            <Text style={{ fontSize: t.xs, color: color, textTransform: 'uppercase', letterSpacing: 1, marginBottom: s.md, fontWeight: t.bold }}>Skills Being Developed</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: s.sm }}>
              {SKILLS.map(skill => (
                <View key={skill} style={{ backgroundColor: color + '18', borderRadius: r.full, paddingHorizontal: s.sm, paddingVertical: 4, borderWidth: 0.5, borderColor: color + '44' }}>
                  <Text style={{ fontSize: 10, color: color }}>{skill}</Text>
                </View>
              ))}
            </View>
          </View>

          {/* Actions */}
          <View style={{ flexDirection: 'row', gap: s.sm, marginTop: s.lg }}>
            {project.status === 'active' && (
              <TouchableOpacity onPress={markComplete}
                style={{ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, backgroundColor: c.bg1, borderRadius: r.md, padding: s.md, borderWidth: 0.5, borderColor: c.border }}>
                <Ionicons name="checkmark-circle-outline" size={16} color={c.teal} />
                <Text style={{ fontSize: t.xs, color: c.teal, fontWeight: t.semibold }}>Mark Complete</Text>
              </TouchableOpacity>
            )}
            <TouchableOpacity style={{ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, backgroundColor: c.bg1, borderRadius: r.md, padding: s.md, borderWidth: 0.5, borderColor: c.border }}>
              <Ionicons name="share-outline" size={16} color={c.text3} />
              <Text style={{ fontSize: t.xs, color: c.text3, fontWeight: t.semibold }}>Share</Text>
            </TouchableOpacity>
          </View>
        </View>
      );

      case 'tasks':      return <TasksSection      projectId={project.id} userId={userId} projectColor={color} c={c} t={t} s={s} r={r} />;
      case 'journal':    return <JournalSection    projectId={project.id} userId={userId} projectColor={color} c={c} t={t} s={s} r={r} />;
      case 'research':   return <ResearchSection   projectId={project.id} userId={userId} projectColor={color} c={c} t={t} s={s} r={r} />;
      case 'timeline':   return <TimelineSection   projectId={project.id} project={project} projectColor={color} c={c} t={t} s={s} r={r} />;
      case 'reflection': return <ReflectionSection projectId={project.id} userId={userId} projectColor={color} prompts={REFLECTION_PROMPTS} c={c} t={t} s={s} r={r} />;
      case 'impact':     return <ReflectionSection projectId={project.id} userId={userId} projectColor={color} prompts={IMPACT_PROMPTS} c={c} t={t} s={s} r={r} />;
      case 'ai':         return <AIMentorSection   project={project} projectColor={color} c={c} t={t} s={s} r={r} />;
      default: return null;
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: c.bg0 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      {/* Header banner */}
      <View style={{ backgroundColor: color + '22', borderBottomWidth: 0.5, borderBottomColor: color + '44' }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', padding: s.lg, paddingTop: s.xl, gap: s.md }}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={{ padding: 4 }}>
            <Ionicons name="chevron-back" size={22} color={color} />
          </TouchableOpacity>
          <Text style={{ fontSize: 28 }}>{project.emoji || '🚀'}</Text>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: t.lg, fontWeight: t.bold, color: c.text1 }} numberOfLines={1}>{project.title}</Text>
            <Text style={{ fontSize: t.xs, color: color, marginTop: 1 }}>
              {project.status === 'active' ? '🚀 Active Mission' : '✅ Complete'}
            </Text>
          </View>
          <TouchableOpacity onPress={() => { setEditTitle(project.title); setEditObj(project.objective || ''); setEditMode(!editMode); setSection('overview'); }}
            style={{ padding: 6 }}>
            <Ionicons name={editMode ? 'close-outline' : 'pencil-outline'} size={18} color={color} />
          </TouchableOpacity>
        </View>

        {/* Section tabs */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: s.lg, paddingBottom: s.md, gap: s.sm }}>
          {SECTIONS.map(sec => (
            <TouchableOpacity key={sec.key} onPress={() => setSection(sec.key)}
              style={{ flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: s.md, paddingVertical: 7, borderRadius: r.full, backgroundColor: section === sec.key ? color : c.bg1, borderWidth: 0.5, borderColor: section === sec.key ? color : c.border }}>
              <Ionicons name={sec.icon} size={13} color={section === sec.key ? '#fff' : c.text3} />
              <Text style={{ fontSize: 11, fontWeight: section === sec.key ? t.bold : t.regular, color: section === sec.key ? '#fff' : c.text3 }}>{sec.label}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {/* Section content */}
      <ScrollView contentContainerStyle={{ padding: s.lg, paddingBottom: 80 }}
        showsVerticalScrollIndicator={false}>
        {renderSection()}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
