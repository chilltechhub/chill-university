// src/screens/library/ProjectDetailScreen.js
// Mission workspace — 1.01 space style + real Supabase data + all 12 sections

import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  TextInput, Modal, ActivityIndicator, Alert,
  KeyboardAvoidingView, Platform, Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';
import { supabase } from '../../api/supabaseClient';

const TABS = [
  { id: 'overview',    name: 'Overview',         icon: 'planet-outline' },
  { id: 'tasks',       name: 'Mission Tasks',    icon: 'checkbox-outline' },
  { id: 'journal',     name: 'Logbook',          icon: 'book-outline' },
  { id: 'research',    name: 'Research Hub',     icon: 'library-outline' },
  { id: 'notes',       name: 'Notes',            icon: 'document-text-outline' },
  { id: 'files',       name: 'Assets & Files',   icon: 'folder-open-outline' },
  { id: 'connections', name: 'Knowledge Graph',  icon: 'git-network-outline' },
  { id: 'skills',      name: 'Skills Unlocked',  icon: 'trophy-outline' },
  { id: 'timeline',    name: 'Timeline',         icon: 'time-outline' },
  { id: 'reflection',  name: 'Reflection',       icon: 'sparkles-outline' },
  { id: 'impact',      name: 'Real-World Impact',icon: 'earth-outline' },
  { id: 'ai',          name: 'Flight Control AI',icon: 'hardware-chip-outline' },
];

const SKILLS_ALL = [
  'Research','Communication','Creativity','Critical Thinking','Leadership',
  'Programming','Engineering','Writing','Design','Collaboration',
  'Problem Solving','Planning','Data Analysis','Public Speaking','Finance',
];

const REFLECTION_PROMPTS = [
  'What did you learn from this project?',
  'What challenges did you face?',
  'What would you do differently?',
  'What surprised you most?',
  'What are your next ideas?',
  'What skills did you build?',
];

const IMPACT_PROMPTS = [
  'What problem does this project solve?',
  'Who benefits from this?',
  'How could this be improved?',
  'Could this become a business?',
  'Could this help your community?',
  'What would version 2 look like?',
];

const RESEARCH_TYPES = [
  { key: 'link',    label: 'Link',    icon: 'link-outline',             color: '#00F0FF' },
  { key: 'article', label: 'Article', icon: 'newspaper-outline',        color: '#7C4DFF' },
  { key: 'video',   label: 'Video',   icon: 'logo-youtube',             color: '#FF4081' },
  { key: 'book',    label: 'Book',    icon: 'book-outline',             color: '#FFB800' },
  { key: 'pdf',     label: 'PDF',     icon: 'document-text-outline',    color: '#00E676' },
  { key: 'note',    label: 'Note',    icon: 'create-outline',           color: '#8E9BB0' },
];

function timeAgo(d) {
  if (!d) return '';
  const diff = Date.now() - new Date(d).getTime();
  const days = Math.floor(diff / 86400000);
  if (days === 0) return 'Today';
  if (days === 1) return 'Yesterday';
  if (days < 7)  return `${days}d ago`;
  return new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

// ─── OVERVIEW ─────────────────────────────────────────────────────────────────
function OverviewModule({ project, userId, color, onUpdate }) {
  const [editMode,   setEditMode]   = useState(false);
  const [editTitle,  setEditTitle]  = useState(project.title || '');
  const [editObj,    setEditObj]    = useState(project.objective || '');

  const save = async () => {
    await supabase.from('projects').update({ title: editTitle, objective: editObj }).eq('id', project.id);
    onUpdate({ ...project, title: editTitle, objective: editObj });
    setEditMode(false);
  };

  const markComplete = () => {
    Alert.alert('Complete Mission?', 'Mark this mission as completed?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Complete 🏆', onPress: async () => {
        await supabase.from('projects').update({ status: 'completed', completed_at: new Date().toISOString() }).eq('id', project.id);
        await supabase.from('project_milestones').insert({ user_id: userId, project_id: project.id, title: '🏆 Mission Complete!', type: 'milestone', date: new Date().toISOString().split('T')[0] });
        onUpdate({ ...project, status: 'completed' });
      }},
    ]);
  };

  return (
    <View style={mod.container}>
      {/* Banner */}
      <View style={[mod.banner, { backgroundColor: color + '22', borderColor: color + '44' }]}>
        <Text style={{ fontSize: 52 }}>{project.emoji || '🚀'}</Text>
        <View style={[mod.statusBadge, { borderColor: color, backgroundColor: color + '18' }]}>
          <Text style={[mod.statusText, { color }]}>{project.status?.toUpperCase() || 'ACTIVE'}</Text>
        </View>
      </View>

      {editMode ? (
        <View style={{ gap: 10, marginBottom: 16 }}>
          <TextInput style={[mod.editInput, { borderColor: color }]}
            value={editTitle} onChangeText={setEditTitle}
            placeholder="Mission name" placeholderTextColor="#626D82" autoFocus />
          <TextInput style={[mod.editInput, { borderColor: '#1F263E', minHeight: 70, textAlignVertical: 'top' }]}
            value={editObj} onChangeText={setEditObj}
            placeholder="Mission objective" placeholderTextColor="#626D82" multiline />
          <TouchableOpacity onPress={save} style={[mod.saveBtn, { backgroundColor: color }]}>
            <Text style={{ color: '#000', fontWeight: '800' }}>Save Changes</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
            <Text style={mod.projTitle}>{project.title}</Text>
            <TouchableOpacity onPress={() => setEditMode(true)} style={{ padding: 4 }}>
              <Ionicons name="pencil-outline" size={18} color={color} />
            </TouchableOpacity>
          </View>
          <Text style={mod.metaText}>
            Launched {new Date(project.created_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
            {project.category ? ` • ${project.category}` : ''}
          </Text>
        </>
      )}

      <View style={mod.glassPanel}>
        <Text style={[mod.panelHeader, { color }]}>🎯 MISSION OBJECTIVE</Text>
        <Text style={mod.panelBody}>{project.objective || 'No objective set — tap ✏️ to add one'}</Text>
      </View>

      {/* Actions */}
      <View style={{ flexDirection: 'row', gap: 10, marginTop: 8 }}>
        {project.status === 'active' && (
          <TouchableOpacity onPress={markComplete} style={mod.actionBtn}>
            <Ionicons name="checkmark-circle-outline" size={16} color="#00E676" />
            <Text style={[mod.actionText, { color: '#00E676' }]}>Mark Complete</Text>
          </TouchableOpacity>
        )}
        <TouchableOpacity style={mod.actionBtn}>
          <Ionicons name="share-social-outline" size={16} color="#8E9BB0" />
          <Text style={[mod.actionText, { color: '#8E9BB0' }]}>Share</Text>
        </TouchableOpacity>
        <TouchableOpacity style={mod.actionBtn}>
          <Ionicons name="easel-outline" size={16} color={color} />
          <Text style={[mod.actionText, { color }]}>Present</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

// ─── TASKS ────────────────────────────────────────────────────────────────────
function TasksModule({ projectId, userId, color }) {
  const [tasks,    setTasks]    = useState([]);
  const [loading,  setLoading]  = useState(true);
  const [input,    setInput]    = useState('');
  const [priority, setPriority] = useState('MED');

  useEffect(() => { load(); }, []);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('project_tasks').select('*').eq('project_id', projectId).order('sort_order');
    if (data) setTasks(data);
    setLoading(false);
  };

  const add = async () => {
    if (!input.trim()) return;
    const { data } = await supabase.from('project_tasks').insert({
      user_id: userId, project_id: projectId, title: input.trim(),
      priority: priority === 'URGENT' ? 1 : priority === 'HIGH' ? 2 : priority === 'MED' ? 3 : 4,
      sort_order: tasks.length,
    }).select().single();
    if (data) setTasks(prev => [...prev, data]);
    setInput('');
  };

  const toggle = async (task) => {
    const completed = !task.completed;
    setTasks(prev => prev.map(t => t.id === task.id ? { ...t, completed } : t));
    await supabase.from('project_tasks').update({ completed, completed_at: completed ? new Date().toISOString() : null }).eq('id', task.id);
    if (completed) {
      await supabase.from('project_milestones').insert({ user_id: userId, project_id: projectId, title: `✅ ${task.title}`, type: 'task_complete', date: new Date().toISOString().split('T')[0] });
    }
  };

  const del = async (id) => {
    setTasks(prev => prev.filter(t => t.id !== id));
    await supabase.from('project_tasks').delete().eq('id', id);
  };

  const done  = tasks.filter(t => t.completed).length;
  const total = tasks.length;
  const pct   = total > 0 ? (done / total) * 100 : 0;

  const PRIOS = ['URGENT','HIGH','MED','LOW'];
  const PRIO_COLORS = { URGENT: '#FF4081', HIGH: '#FFB800', MED: '#00F0FF', LOW: '#626D82' };

  if (loading) return <ActivityIndicator color={color} style={{ marginTop: 20 }} />;

  return (
    <View style={mod.container}>
      <Text style={mod.modTitle}>📋 Mission Directives</Text>

      {total > 0 && (
        <View style={{ marginBottom: 16 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 }}>
            <Text style={mod.metaText}>Mission Progress</Text>
            <Text style={[mod.metaText, { color }]}>{done}/{total} complete</Text>
          </View>
          <View style={mod.progressBg}>
            <View style={[mod.progressFill, { width: `${pct}%`, backgroundColor: color }]} />
          </View>
        </View>
      )}

      {/* Priority selector */}
      <View style={{ flexDirection: 'row', gap: 6, marginBottom: 10 }}>
        {PRIOS.map(p => (
          <TouchableOpacity key={p} onPress={() => setPriority(p)}
            style={[mod.prioBtn, priority === p && { borderColor: PRIO_COLORS[p], backgroundColor: PRIO_COLORS[p] + '18' }]}>
            <Text style={[mod.prioText, priority === p && { color: PRIO_COLORS[p] }]}>{p}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Add input */}
      <View style={{ flexDirection: 'row', gap: 8, marginBottom: 16 }}>
        <TextInput style={[mod.editInput, { flex: 1, borderColor: color }]}
          value={input} onChangeText={setInput}
          placeholder="New directive..." placeholderTextColor="#626D82"
          onSubmitEditing={add} />
        <TouchableOpacity onPress={add} style={[mod.saveBtn, { backgroundColor: color, paddingHorizontal: 14 }]}>
          <Ionicons name="add" size={20} color="#000" />
        </TouchableOpacity>
      </View>

      {tasks.map(task => {
        const prioLabel = task.priority === 1 ? 'URGENT' : task.priority === 2 ? 'HIGH' : task.priority === 3 ? 'MED' : 'LOW';
        const prioColor = PRIO_COLORS[prioLabel];
        return (
          <View key={task.id} style={mod.taskCard}>
            <TouchableOpacity onPress={() => toggle(task)}>
              <Ionicons name={task.completed ? 'checkbox' : 'square-outline'} size={22}
                color={task.completed ? '#00E676' : color} />
            </TouchableOpacity>
            <Text style={[mod.taskTitle, task.completed && mod.taskDone]} numberOfLines={2}>{task.title}</Text>
            <View style={[mod.prioBadge, { backgroundColor: prioColor + '20' }]}>
              <Text style={[mod.prioText, { color: prioColor, fontWeight: '800' }]}>{prioLabel}</Text>
            </View>
            <TouchableOpacity onPress={() => del(task.id)}>
              <Ionicons name="close" size={15} color="#626D82" />
            </TouchableOpacity>
          </View>
        );
      })}

      {tasks.length === 0 && (
        <View style={mod.empty}>
          <Text style={{ fontSize: 36, marginBottom: 8 }}>📋</Text>
          <Text style={mod.emptyText}>No directives yet — add one above</Text>
        </View>
      )}
    </View>
  );
}

// ─── JOURNAL (LOGBOOK) ────────────────────────────────────────────────────────
function JournalModule({ projectId, userId, color }) {
  const [entries,  setEntries]  = useState([]);
  const [loading,  setLoading]  = useState(true);
  const [showAdd,  setShowAdd]  = useState(false);
  const [body,     setBody]     = useState('');
  const [title,    setTitle]    = useState('');
  const [mood,     setMood]     = useState('');
  const MOODS = ['🔥','💡','😊','😤','😴','🎉','🤔','💪'];

  useEffect(() => { load(); }, []);
  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('project_journal').select('*').eq('project_id', projectId).order('created_at', { ascending: false });
    if (data) setEntries(data);
    setLoading(false);
  };

  const add = async () => {
    if (!body.trim()) return;
    const { data } = await supabase.from('project_journal').insert({ user_id: userId, project_id: projectId, title: title.trim() || null, body: body.trim(), mood: mood || null }).select().single();
    if (data) { setEntries(prev => [data, ...prev]); setTitle(''); setBody(''); setMood(''); setShowAdd(false); }
  };

  if (loading) return <ActivityIndicator color={color} style={{ marginTop: 20 }} />;

  return (
    <View style={mod.container}>
      <Text style={mod.modTitle}>📖 Captain's Logbook</Text>
      <TouchableOpacity onPress={() => setShowAdd(!showAdd)} style={[mod.importBtn, { backgroundColor: color }]}>
        <Ionicons name="add" size={18} color="#000" />
        <Text style={{ color: '#000', fontWeight: '800' }}>New Log Entry</Text>
      </TouchableOpacity>

      {showAdd && (
        <View style={[mod.glassPanel, { borderColor: color + '44' }]}>
          <View style={{ flexDirection: 'row', gap: 6, marginBottom: 10 }}>
            {MOODS.map(mo => (
              <TouchableOpacity key={mo} onPress={() => setMood(mood === mo ? '' : mo)}
                style={{ padding: 6, borderRadius: 8, backgroundColor: mood === mo ? color + '33' : 'transparent' }}>
                <Text style={{ fontSize: 20 }}>{mo}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <TextInput style={[mod.editInput, { borderColor: '#1F263E', marginBottom: 8 }]}
            value={title} onChangeText={setTitle} placeholder="Entry title (optional)" placeholderTextColor="#626D82" />
          <TextInput style={[mod.editInput, { borderColor: '#1F263E', minHeight: 80, textAlignVertical: 'top', marginBottom: 10 }]}
            value={body} onChangeText={setBody} placeholder="What happened? What did you learn? What's next?" placeholderTextColor="#626D82" multiline autoFocus />
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <TouchableOpacity onPress={() => setShowAdd(false)} style={[mod.actionBtn, { flex: 1, justifyContent: 'center' }]}>
              <Text style={{ color: '#8E9BB0', fontWeight: '600', fontSize: 13 }}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={add} disabled={!body.trim()} style={[mod.saveBtn, { flex: 2, backgroundColor: color, opacity: !body.trim() ? 0.5 : 1 }]}>
              <Text style={{ color: '#000', fontWeight: '800' }}>Save Log</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {entries.length === 0 && !showAdd ? (
        <View style={mod.empty}><Text style={{ fontSize: 36, marginBottom: 8 }}>📖</Text><Text style={mod.emptyText}>No log entries yet</Text></View>
      ) : (
        entries.map(entry => (
          <View key={entry.id} style={mod.journalEntry}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                {entry.mood && <Text style={{ fontSize: 16 }}>{entry.mood}</Text>}
                <Text style={[mod.journalDate, { color }]}>STARDATE: {new Date(entry.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }).toUpperCase()}</Text>
              </View>
            </View>
            {entry.title && <Text style={mod.journalTitle}>{entry.title}</Text>}
            <Text style={mod.journalBody}>{entry.body}</Text>
          </View>
        ))
      )}
    </View>
  );
}

// ─── RESEARCH HUB ─────────────────────────────────────────────────────────────
function ResearchModule({ projectId, userId, color }) {
  const [items,   setItems]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [title,   setTitle]   = useState('');
  const [url,     setUrl]     = useState('');
  const [notes,   setNotes]   = useState('');
  const [type,    setType]    = useState('link');

  useEffect(() => { load(); }, []);
  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('project_research').select('*').eq('project_id', projectId).order('created_at', { ascending: false });
    if (data) setItems(data);
    setLoading(false);
  };

  const add = async () => {
    if (!title.trim()) return;
    const { data } = await supabase.from('project_research').insert({ user_id: userId, project_id: projectId, title: title.trim(), url: url.trim() || null, notes: notes.trim() || null, type }).select().single();
    if (data) { setItems(prev => [data, ...prev]); setTitle(''); setUrl(''); setNotes(''); setShowAdd(false); }
  };

  if (loading) return <ActivityIndicator color={color} style={{ marginTop: 20 }} />;

  return (
    <View style={mod.container}>
      <Text style={mod.modTitle}>📚 Research Intelligence</Text>
      <TouchableOpacity onPress={() => setShowAdd(!showAdd)} style={[mod.importBtn, { backgroundColor: '#7C4DFF' }]}>
        <Ionicons name="cloud-upload-outline" size={18} color="#FFF" />
        <Text style={{ color: '#FFF', fontWeight: '800' }}>Import Resource / URL</Text>
      </TouchableOpacity>

      {showAdd && (
        <View style={[mod.glassPanel, { borderColor: '#7C4DFF44' }]}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 10 }}>
            <View style={{ flexDirection: 'row', gap: 7 }}>
              {RESEARCH_TYPES.map(rt => (
                <TouchableOpacity key={rt.key} onPress={() => setType(rt.key)}
                  style={[mod.typeChipSm, type === rt.key && { borderColor: rt.color, backgroundColor: rt.color + '18' }]}>
                  <Ionicons name={rt.icon} size={13} color={type === rt.key ? rt.color : '#626D82'} />
                  <Text style={[{ fontSize: 11, color: '#626D82' }, type === rt.key && { color: rt.color }]}>{rt.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
          <TextInput style={[mod.editInput, { borderColor: '#1F263E', marginBottom: 8 }]}
            value={title} onChangeText={setTitle} placeholder="Title *" placeholderTextColor="#626D82" autoFocus />
          <TextInput style={[mod.editInput, { borderColor: '#1F263E', marginBottom: 8 }]}
            value={url} onChangeText={setUrl} placeholder="URL (optional)" placeholderTextColor="#626D82" autoCapitalize="none" />
          <TextInput style={[mod.editInput, { borderColor: '#1F263E', marginBottom: 10, minHeight: 50, textAlignVertical: 'top' }]}
            value={notes} onChangeText={setNotes} placeholder="Notes..." placeholderTextColor="#626D82" multiline />
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <TouchableOpacity onPress={() => setShowAdd(false)} style={[mod.actionBtn, { flex: 1, justifyContent: 'center' }]}>
              <Text style={{ color: '#8E9BB0', fontWeight: '600', fontSize: 13 }}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={add} disabled={!title.trim()} style={[mod.saveBtn, { flex: 2, backgroundColor: '#7C4DFF', opacity: !title.trim() ? 0.5 : 1 }]}>
              <Text style={{ color: '#FFF', fontWeight: '800' }}>Save</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      <View style={mod.researchGrid}>
        {items.map(item => {
          const rt = RESEARCH_TYPES.find(r => r.key === item.type) || RESEARCH_TYPES[0];
          return (
            <View key={item.id} style={mod.researchCard}>
              <Ionicons name={rt.icon} size={22} color={rt.color} />
              <View style={{ flex: 1, marginLeft: 10 }}>
                <Text style={mod.researchTitle}>{item.title}</Text>
                <Text style={mod.researchType}>{rt.label}</Text>
                {item.url && <Text style={{ color: rt.color, fontSize: 10, marginTop: 2 }} numberOfLines={1}>{item.url}</Text>}
              </View>
            </View>
          );
        })}
      </View>

      {items.length === 0 && !showAdd && (
        <View style={mod.empty}><Text style={{ fontSize: 36, marginBottom: 8 }}>📚</Text><Text style={mod.emptyText}>No resources yet — import one above</Text></View>
      )}
    </View>
  );
}

// ─── NOTES ────────────────────────────────────────────────────────────────────
function NotesModule({ projectId, userId, color }) {
  const [notes,   setNotes]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [input,   setInput]   = useState('');
  const [title,   setTitle]   = useState('');
  const [showAdd, setShowAdd] = useState(false);

  useEffect(() => { load(); }, []);
  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('project_journal').select('*').eq('project_id', projectId).eq('type', 'note').order('created_at', { ascending: false });
    if (data) setNotes(data);
    setLoading(false);
  };

  const add = async () => {
    if (!input.trim()) return;
    const { data } = await supabase.from('project_journal').insert({ user_id: userId, project_id: projectId, title: title.trim() || null, body: input.trim(), type: 'note' }).select().single();
    if (data) { setNotes(prev => [data, ...prev]); setTitle(''); setInput(''); setShowAdd(false); }
  };

  const del = async (id) => {
    setNotes(prev => prev.filter(n => n.id !== id));
    await supabase.from('project_journal').delete().eq('id', id);
  };

  if (loading) return <ActivityIndicator color={color} style={{ marginTop: 20 }} />;

  return (
    <View style={mod.container}>
      <Text style={mod.modTitle}>📝 Lab Notes</Text>
      <TouchableOpacity onPress={() => setShowAdd(!showAdd)} style={[mod.importBtn, { backgroundColor: color }]}>
        <Ionicons name="add" size={18} color="#000" />
        <Text style={{ color: '#000', fontWeight: '800' }}>New Note</Text>
      </TouchableOpacity>

      {showAdd && (
        <View style={[mod.glassPanel, { borderColor: color + '44' }]}>
          <TextInput style={[mod.editInput, { borderColor: '#1F263E', marginBottom: 8 }]}
            value={title} onChangeText={setTitle} placeholder="Note title (optional)" placeholderTextColor="#626D82" />
          <TextInput style={[mod.editInput, { borderColor: '#1F263E', minHeight: 80, textAlignVertical: 'top', marginBottom: 10 }]}
            value={input} onChangeText={setInput} placeholder="Write your note..." placeholderTextColor="#626D82" multiline autoFocus />
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <TouchableOpacity onPress={() => setShowAdd(false)} style={[mod.actionBtn, { flex: 1, justifyContent: 'center' }]}>
              <Text style={{ color: '#8E9BB0', fontWeight: '600', fontSize: 13 }}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={add} disabled={!input.trim()} style={[mod.saveBtn, { flex: 2, backgroundColor: color, opacity: !input.trim() ? 0.5 : 1 }]}>
              <Text style={{ color: '#000', fontWeight: '800' }}>Save</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {notes.map(note => (
        <View key={note.id} style={[mod.glassPanel, { borderLeftWidth: 3, borderLeftColor: color }]}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 }}>
            <Text style={[mod.panelHeader, { color }]}>{note.title || '⚡ NOTE'}</Text>
            <View style={{ flexDirection: 'row', gap: 10, alignItems: 'center' }}>
              <Text style={{ color: '#626D82', fontSize: 10 }}>{timeAgo(note.created_at)}</Text>
              <TouchableOpacity onPress={() => del(note.id)}>
                <Ionicons name="close" size={15} color="#626D82" />
              </TouchableOpacity>
            </View>
          </View>
          <Text style={mod.panelBody}>{note.body}</Text>
        </View>
      ))}

      {notes.length === 0 && !showAdd && (
        <View style={mod.empty}><Text style={{ fontSize: 36, marginBottom: 8 }}>📝</Text><Text style={mod.emptyText}>No notes yet</Text></View>
      )}
    </View>
  );
}

// ─── FILES & ASSETS ───────────────────────────────────────────────────────────
function FilesModule({ color }) {
  const FILE_TYPES = [
    { icon: 'cube-outline',          color: '#FFB800', label: 'CAD / 3D' },
    { icon: 'document-text-outline', color: '#00F0FF', label: 'Document' },
    { icon: 'image-outline',         color: '#7C4DFF', label: 'Image' },
    { icon: 'code-slash-outline',    color: '#00E676', label: 'Code' },
    { icon: 'videocam-outline',      color: '#FF4081', label: 'Video' },
    { icon: 'musical-notes-outline', color: '#FFB800', label: 'Audio' },
  ];
  return (
    <View style={mod.container}>
      <Text style={mod.modTitle}>📂 Assets & File Storage</Text>
      <TouchableOpacity style={[mod.importBtn, { backgroundColor: '#7C4DFF' }]}>
        <Ionicons name="cloud-upload-outline" size={18} color="#FFF" />
        <Text style={{ color: '#FFF', fontWeight: '800' }}>Upload File / Link Storage</Text>
      </TouchableOpacity>
      <View style={mod.glassPanel}>
        <Text style={[mod.panelHeader, { color }]}>SUPPORTED FILE TYPES</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 8 }}>
          {FILE_TYPES.map((ft, i) => (
            <View key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#06080F', padding: 8, borderRadius: 8 }}>
              <Ionicons name={ft.icon} size={16} color={ft.color} />
              <Text style={{ color: '#8E9BB0', fontSize: 11 }}>{ft.label}</Text>
            </View>
          ))}
        </View>
        <Text style={[mod.panelBody, { marginTop: 12 }]}>File upload integration coming in next build. Link external storage (Google Drive, GitHub, Dropbox) to attach assets.</Text>
      </View>
    </View>
  );
}

// ─── CONNECTIONS / KNOWLEDGE GRAPH ────────────────────────────────────────────
function ConnectionsModule({ project, color }) {
  return (
    <View style={mod.container}>
      <Text style={mod.modTitle}>🕸️ Knowledge Graph</Text>
      <View style={mod.glassPanel}>
        <Text style={[mod.panelHeader, { color }]}>CONNECTED TO</Text>
        <Text style={[mod.panelBody, { marginBottom: 12 }]}>This project will link to related notes, ideas, and subjects as you build your knowledge graph.</Text>
        <View style={{ alignItems: 'center', paddingVertical: 20 }}>
          <Ionicons name="git-network-outline" size={60} color={color} style={{ opacity: 0.4 }} />
          <Text style={[mod.emptyText, { marginTop: 10 }]}>Knowledge graph visualization coming soon</Text>
        </View>
      </View>
    </View>
  );
}

// ─── SKILLS ───────────────────────────────────────────────────────────────────
function SkillsModule({ project, color }) {
  const [unlocked, setUnlocked] = useState(project.skills || []);

  const toggle = async (skill) => {
    const next = unlocked.includes(skill) ? unlocked.filter(s => s !== skill) : [...unlocked, skill];
    setUnlocked(next);
    await supabase.from('projects').update({ skills: next }).eq('id', project.id);
  };

  return (
    <View style={mod.container}>
      <Text style={mod.modTitle}>🏆 Skills Unlocked</Text>
      <Text style={mod.metaText}>Tap skills you've developed through this mission.</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 }}>
        {SKILLS_ALL.map(skill => {
          const isOn = unlocked.includes(skill);
          return (
            <TouchableOpacity key={skill} onPress={() => toggle(skill)}
              style={[mod.skillChip, isOn && { borderColor: '#00E676', backgroundColor: 'rgba(0,230,118,0.1)' }]}>
              <Ionicons name="shield-checkmark" size={13} color={isOn ? '#00E676' : '#626D82'} />
              <Text style={[{ color: '#626D82', fontSize: 12, fontWeight: '600' }, isOn && { color: '#00E676' }]}>{skill}</Text>
            </TouchableOpacity>
          );
        })}
      </View>
      {unlocked.length > 0 && (
        <View style={[mod.glassPanel, { marginTop: 16 }]}>
          <Text style={[mod.panelHeader, { color: '#00E676' }]}>TELEMETRY: {unlocked.length} SKILLS LOGGED</Text>
          <Text style={mod.panelBody}>These skills are being tracked and will appear on your profile and portfolio.</Text>
        </View>
      )}
    </View>
  );
}

// ─── TIMELINE ─────────────────────────────────────────────────────────────────
function TimelineModule({ projectId, color }) {
  const [milestones, setMilestones] = useState([]);
  const [loading,    setLoading]    = useState(true);

  useEffect(() => { load(); }, []);
  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('project_milestones').select('*').eq('project_id', projectId).order('created_at');
    if (data) setMilestones(data);
    setLoading(false);
  };

  const TYPE_ICONS = { project_created:'🚀', task_complete:'✅', file_add:'📁', journal:'📓', milestone:'🏆' };

  if (loading) return <ActivityIndicator color={color} style={{ marginTop: 20 }} />;

  return (
    <View style={mod.container}>
      <Text style={mod.modTitle}>⏳ Chronological Log</Text>
      {milestones.length === 0 ? (
        <View style={mod.empty}><Text style={{ fontSize: 36, marginBottom: 8 }}>⏳</Text><Text style={mod.emptyText}>Timeline builds as you work</Text></View>
      ) : (
        milestones.map((m, i) => (
          <View key={m.id} style={{ flexDirection: 'row', gap: 12, marginBottom: 12 }}>
            <View style={{ alignItems: 'center' }}>
              <View style={[mod.timelineDot, { backgroundColor: color }]} />
              {i < milestones.length - 1 && <View style={[mod.timelineLine, { backgroundColor: color + '33' }]} />}
            </View>
            <View style={[mod.glassPanel, { flex: 1, marginBottom: 0 }]}>
              <Text style={[mod.journalDate, { color }]}>{new Date(m.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }).toUpperCase()}</Text>
              <Text style={mod.journalTitle}>{TYPE_ICONS[m.type] || '⭐'} {m.title}</Text>
            </View>
          </View>
        ))
      )}
    </View>
  );
}

// ─── REFLECTION ───────────────────────────────────────────────────────────────
function ReflectionModule({ projectId, userId, color, prompts }) {
  const [answers, setAnswers] = useState({});
  const [saving,  setSaving]  = useState(null);

  const save = async (prompt, text) => {
    setSaving(prompt);
    await supabase.from('project_journal').upsert({ user_id: userId, project_id: projectId, title: prompt, body: text, type: 'reflection' });
    setSaving(null);
  };

  return (
    <View style={mod.container}>
      <Text style={mod.modTitle}>🪞 Post-Mission Reflection</Text>
      {prompts.map((prompt, i) => (
        <View key={i} style={[mod.glassPanel, { borderLeftWidth: 3, borderLeftColor: color }]}>
          <Text style={[mod.questionText, { color }]}>{prompt}</Text>
          <TextInput
            style={mod.reflectionInput}
            value={answers[prompt] || ''}
            onChangeText={text => setAnswers(prev => ({ ...prev, [prompt]: text }))}
            onBlur={() => answers[prompt]?.trim() && save(prompt, answers[prompt])}
            placeholder="Document your answer..." placeholderTextColor="#626D82"
            multiline />
          {saving === prompt && <ActivityIndicator size="small" color={color} style={{ alignSelf: 'flex-end', marginTop: 4 }} />}
        </View>
      ))}
    </View>
  );
}

// ─── AI MENTOR ────────────────────────────────────────────────────────────────
function AIMentorModule({ project, color }) {
  const [messages, setMessages] = useState([
    { role: 'assistant', text: `🤖 Greetings Commander! I'm your Flight Control AI for **${project.title}**. I can help you generate timelines, review your work, brainstorm solutions, or answer questions. What do you need?` }
  ]);
  const [input,   setInput]   = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);

  const QUICK = ['Generate timeline', 'Break into tasks', 'Brainstorm ideas', 'Review progress', 'Suggest resources'];

  const send = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);
    try {
      const ctx = `You are Flight Control AI, an expert mentor for a project called "${project.title}". ${project.objective ? `Objective: ${project.objective}.` : ''} Be encouraging, specific, and concise.`;
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-6', max_tokens: 1000,
          system: ctx,
          messages: messages.filter((_, i) => i > 0).concat([{ role: 'user', content: userMsg }]).map(m => ({ role: m.role, content: m.text })),
        }),
      });
      const data = await res.json();
      const reply = data.content?.[0]?.text || 'Connection error. Try again.';
      setMessages(prev => [...prev, { role: 'assistant', text: reply }]);
    } catch {
      setMessages(prev => [...prev, { role: 'assistant', text: 'Connection error. Try again.' }]);
    }
    setLoading(false);
    setTimeout(() => scrollRef.current?.scrollToEnd(), 100);
  };

  return (
    <View style={mod.container}>
      <Text style={mod.modTitle}>🤖 Flight Control AI</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 12 }}>
        <View style={{ flexDirection: 'row', gap: 7 }}>
          {QUICK.map(qp => (
            <TouchableOpacity key={qp} onPress={() => setInput(qp)}
              style={[mod.typeChipSm, { borderColor: color + '55', backgroundColor: color + '18' }]}>
              <Text style={{ fontSize: 11, color }}>{qp}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      <View style={[mod.glassPanel, { minHeight: 180 }]}>
        <ScrollView ref={scrollRef} style={{ maxHeight: 250 }} contentContainerStyle={{ gap: 8 }}>
          {messages.map((msg, i) => (
            <View key={i} style={[mod.aiMsg, msg.role === 'user' ? { alignSelf: 'flex-end', backgroundColor: color + '22', borderColor: color + '44' } : { alignSelf: 'flex-start', backgroundColor: '#1F263E' }]}>
              <Text style={{ color: '#E0D7FF', fontSize: 13, lineHeight: 19 }}>{msg.text}</Text>
            </View>
          ))}
          {loading && <View style={[mod.aiMsg, { alignSelf: 'flex-start', backgroundColor: '#1F263E' }]}><ActivityIndicator size="small" color={color} /></View>}
        </ScrollView>
      </View>

      <View style={{ flexDirection: 'row', gap: 8, marginTop: 10 }}>
        <TextInput style={[mod.editInput, { flex: 1, borderColor: '#1F263E' }]}
          value={input} onChangeText={setInput}
          placeholder="Ask Flight Control..." placeholderTextColor="#626D82"
          onSubmitEditing={send} returnKeyType="send" />
        <TouchableOpacity onPress={send} disabled={!input.trim() || loading}
          style={[mod.saveBtn, { backgroundColor: color, paddingHorizontal: 14, opacity: (!input.trim() || loading) ? 0.5 : 1 }]}>
          <Ionicons name="send" size={16} color="#000" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

// ─── SHARED STYLES ─────────────────────────────────────────────────────────────
const mod = StyleSheet.create({
  container:     { flex: 1 },
  modTitle:      { color: '#FFF', fontSize: 18, fontWeight: 'bold', marginBottom: 16 },
  metaText:      { color: '#8E9BB0', fontSize: 12, marginBottom: 10 },
  banner:        { height: 120, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginBottom: 16, borderWidth: 1, position: 'relative' },
  statusBadge:   { position: 'absolute', top: 10, right: 10, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3, borderWidth: 1 },
  statusText:    { fontSize: 9, fontWeight: '800', letterSpacing: 0.5 },
  projTitle:     { color: '#FFF', fontSize: 20, fontWeight: 'bold', flex: 1 },
  glassPanel:    { backgroundColor: '#141829', padding: 16, borderRadius: 12, borderWidth: 1, borderColor: '#1F263E', marginBottom: 12 },
  panelHeader:   { fontSize: 11, fontWeight: '800', letterSpacing: 1.5, marginBottom: 8 },
  panelBody:     { color: '#A0AABF', fontSize: 13, lineHeight: 20 },
  progressBg:    { height: 6, backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 3, overflow: 'hidden' },
  progressFill:  { height: '100%', borderRadius: 3 },
  editInput:     { backgroundColor: '#141829', borderRadius: 10, padding: 12, fontSize: 14, color: '#FFF', borderWidth: 1 },
  saveBtn:       { borderRadius: 10, padding: 12, alignItems: 'center', justifyContent: 'center' },
  actionBtn:     { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#141829', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8, borderWidth: 1, borderColor: '#1F263E' },
  actionText:    { fontSize: 12, fontWeight: '600' },
  taskCard:      { flexDirection: 'row', alignItems: 'center', backgroundColor: '#141829', padding: 12, borderRadius: 10, marginBottom: 8, borderWidth: 1, borderColor: '#1F263E', gap: 10 },
  taskTitle:     { flex: 1, color: '#FFF', fontSize: 14, lineHeight: 19 },
  taskDone:      { textDecorationLine: 'line-through', color: '#626D82' },
  prioBtn:       { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8, borderWidth: 1, borderColor: '#1F263E', backgroundColor: '#141829' },
  prioBadge:     { paddingHorizontal: 7, paddingVertical: 2, borderRadius: 6 },
  prioText:      { fontSize: 9, color: '#626D82' },
  importBtn:     { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8, padding: 12, borderRadius: 10, marginBottom: 14 },
  researchGrid:  { gap: 10 },
  researchCard:  { flexDirection: 'row', alignItems: 'flex-start', backgroundColor: '#141829', padding: 14, borderRadius: 10, borderWidth: 1, borderColor: '#1F263E' },
  researchTitle: { color: '#FFF', fontWeight: 'bold', fontSize: 13, marginBottom: 2 },
  researchType:  { color: '#626D82', fontSize: 10 },
  typeChipSm:    { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 14, borderWidth: 1, borderColor: '#1F263E', backgroundColor: '#141829' },
  journalEntry:  { backgroundColor: '#141829', padding: 14, borderRadius: 10, borderLeftWidth: 3, marginBottom: 10 },
  journalDate:   { fontSize: 10, fontWeight: '800', letterSpacing: 1, marginBottom: 4 },
  journalTitle:  { color: '#FFF', fontWeight: '700', fontSize: 14, marginBottom: 4 },
  journalBody:   { color: '#A0AABF', fontSize: 13, lineHeight: 19 },
  questionText:  { color: '#FFF', fontWeight: '600', marginBottom: 10, fontSize: 14 },
  reflectionInput:{ backgroundColor: '#06080F', color: '#FFF', borderRadius: 8, padding: 12, minHeight: 70, textAlignVertical: 'top' },
  skillChip:     { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(255,255,255,0.05)', paddingHorizontal: 12, paddingVertical: 7, borderRadius: 16, borderWidth: 1, borderColor: '#1F263E' },
  timelineDot:   { width: 12, height: 12, borderRadius: 6, marginTop: 6 },
  timelineLine:  { width: 2, flex: 1, marginTop: 4 },
  aiMsg:         { borderRadius: 10, padding: 10, borderWidth: 1, borderColor: '#1F263E', maxWidth: '85%' },
  empty:         { alignItems: 'center', paddingVertical: 40 },
  emptyText:     { color: '#626D82', fontSize: 13 },
});

// ─── Main ProjectDetailScreen ──────────────────────────────────────────────────
export default function ProjectDetailScreen() {
  const navigation = useNavigation();
  const route      = useRoute();

  const [project, setProject] = useState(route.params?.project);
  const [tab,     setTab]     = useState('overview');
  const [userId,  setUserId]  = useState(null);

  const color = project?.color || '#00F0FF';

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => { if (user) setUserId(user.id); });
  }, []);

  if (!project) return null;

  const renderTab = () => {
    const props = { projectId: project.id, userId, color, project };
    switch (tab) {
      case 'overview':    return <OverviewModule    {...props} onUpdate={setProject} />;
      case 'tasks':       return <TasksModule       {...props} />;
      case 'journal':     return <JournalModule     {...props} />;
      case 'research':    return <ResearchModule    {...props} />;
      case 'notes':       return <NotesModule       {...props} />;
      case 'files':       return <FilesModule       {...props} />;
      case 'connections': return <ConnectionsModule {...props} />;
      case 'skills':      return <SkillsModule      {...props} />;
      case 'timeline':    return <TimelineModule    {...props} />;
      case 'reflection':  return <ReflectionModule  {...props} prompts={REFLECTION_PROMPTS} />;
      case 'impact':      return <ReflectionModule  {...props} prompts={IMPACT_PROMPTS} />;
      case 'ai':          return <AIMentorModule    {...props} />;
      default: return null;
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#0B0D17' }}>
      {/* Top nav */}
      <View style={det.topNav}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#FFF" />
        </TouchableOpacity>
        <Text style={det.missionCode} numberOfLines={1}>
          {project.emoji} {project.title.toUpperCase()}
        </Text>
        <TouchableOpacity style={det.presentBtn}>
          <Ionicons name="easel-outline" size={16} color={color} />
          <Text style={[det.presentText, { color }]}>Present</Text>
        </TouchableOpacity>
      </View>

      {/* Tab bar */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={det.tabBar}>
        {TABS.map(t => (
          <TouchableOpacity key={t.id} onPress={() => setTab(t.id)}
            style={[det.tabItem, tab === t.id && det.tabActive]}>
            <Ionicons name={t.icon} size={15} color={tab === t.id ? color : '#626D82'} />
            <Text style={[det.tabLabel, tab === t.id && { color, fontWeight: '700' }]}>{t.name}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Content */}
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 60 }} showsVerticalScrollIndicator={false}>
          {renderTab()}
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const det = StyleSheet.create({
  topNav:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, paddingTop: 20, paddingBottom: 12 },
  missionCode: { color: '#FFF', fontSize: 13, fontWeight: 'bold', letterSpacing: 0.5, flex: 1, marginHorizontal: 12 },
  presentBtn:  { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 12, borderWidth: 1, borderColor: '#1F263E', backgroundColor: 'rgba(0,240,255,0.08)' },
  presentText: { fontSize: 11, fontWeight: 'bold' },
  tabBar:      { borderBottomWidth: 1, borderBottomColor: '#1F263E', maxHeight: 48 },
  tabItem:     { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 12, borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabActive:   { borderBottomColor: '#00F0FF' },
  tabLabel:    { color: '#626D82', fontSize: 12, fontWeight: '600' },
});
